//+------------------------------------------------------------------+
//|  MoneyMachine7.mq5  -  v1.0.0                                    |
//|  XAUUSD M1 Expert Advisor - Modular Architecture                 |
//+------------------------------------------------------------------+
#property copyright "Money Machine 7"
#property version   "1.00"
#property strict

//--- Includes (order matters: dependencies first)
#include "Include/MM7/Utils/Logger.mqh"
#include "Include/MM7/Core/DataStructures.mqh"
#include "Include/MM7/Market/IndicatorCache.mqh"
#include "Include/MM7/Core/Validator.mqh"
#include "Include/MM7/Market/SMCDetector.mqh"
#include "Include/MM7/Market/PriceActionAnalyzer.mqh"
#include "Include/MM7/Position/OrderExecutor.mqh"
#include "Include/MM7/Position/PositionTracker.mqh"
#include "Include/MM7/Position/StealthModeManager.mqh"
#include "Include/MM7/Position/BasketManager.mqh"
#include "Include/MM7/Risk/PositionSizer.mqh"
#include "Include/MM7/Risk/TPSLCalculator.mqh"
#include "Include/MM7/Risk/TrailingStop.mqh"
#include "Include/MM7/Risk/Breakeven.mqh"
#include "Include/MM7/Risk/RiskLimitsMonitor.mqh"
#include "Include/MM7/Risk/RecoveryMode.mqh"
#include "Include/MM7/Filters/TrendFilter.mqh"
#include "Include/MM7/Filters/NewsFilter.mqh"
#include "Include/MM7/Filters/SpreadFilter.mqh"
#include "Include/MM7/Filters/ScheduleFilter.mqh"
#include "Include/MM7/Filters/StochasticFilter.mqh"
#include "Include/MM7/Filters/FilterManager.mqh"
#include "Include/MM7/Strategies/SMCStrategy.mqh"
#include "Include/MM7/Strategies/BreakoutStrategy.mqh"
#include "Include/MM7/Strategies/StopHuntStrategy.mqh"
#include "Include/MM7/Strategies/GridStrategy.mqh"
#include "Include/MM7/Strategies/StrategyManager.mqh"
#include "Include/MM7/Utils/HistoryLabels.mqh"

//==================================================================
//  INPUT PARAMETERS
//==================================================================
input group "=== Core ==="
input int    Magic_Number              = 700000;
input string Comment_Text              = "MM7";
input bool   Control_orders_user       = false;

input group "=== Smart Money Concepts ==="
input ENUM_SMC_MODE SMC_Mode           = SMC_HYBRID;
input int    FVG_Lookback_Bars         = 1200;
input double Min_FVG_Size_Points       = 10.0;
input bool   Draw_FVG_Zones            = true;
input int    OB_Lookback_Bars          = 1200;
input double OB_Min_Body_Percent       = 50.0;
input bool   Draw_OB_Zones             = true;

input group "=== Grid System ==="
input int    Grid_Intensity            = 2;        // 0=Off 1=Cons 2=Mod 3=Aggr
input int    ADR_Period_Days           = 14;
input double Grid_Distance_Multiplier  = 1.0;
input double Custom_ADR_Divider        = 1.0;
input int    Max_Buy                   = 5;
input int    Max_Sell                  = 5;
input bool   Use_Grid_Stoch_Filter     = true;
input double Stoch_Buy_Level           = 20.0;
input double Stoch_Sell_Level          = 80.0;

input group "=== Breakout Strategy ==="
input bool   Enable_Breakout           = true;
input int    Breakout_Period           = 50;
input double Breakout_Buffer_Pts       = 5.0;
input double Min_Breakout_Range_Pts    = 20.0;
input bool   Use_RSI_Confirm           = true;
input int    RSI_Period                = 14;
input double RSI_Buy_Threshold         = 50.0;
input double RSI_Sell_Threshold        = 50.0;
input bool   Use_Volume_Confirm        = true;
input int    Volume_MA_Period          = 20;

input group "=== Stop Hunt Strategy ==="
input bool   Enable_StopHunt           = true;
input int    Swing_Lookback            = 50;
input double Hunt_Confirm_Pts          = 5.0;

input group "=== Lot Sizing ==="
input double Lot                       = 0.01;
input bool   Use_Dynamic_Lot           = true;
input double Free_Margin_Per_Lot       = 1000.0;
input double Max_Lot                   = 10.0;
input double Kmartin                   = 1.0;

input group "=== TP / SL ==="
input bool   Use_Auto_TP               = true;
input double Auto_TP_Ratio             = 2.0;
input bool   Use_Auto_SL               = true;
input double Auto_SL_Ratio             = 1.0;
input int    ATR_Period                = 14;
input bool   Use_Stealth_Mode          = true;

input group "=== Trailing Stop ==="
input bool   Enable_TrailingStop       = true;
input double TS_Start_ATR_Mult         = 1.5;
input double TS_Distance_ATR_Mult      = 1.0;

input group "=== Breakeven ==="
input bool   Enable_Breakeven          = true;
input double BE_Trigger_ATR_Mult       = 1.0;
input double BE_Profit_Points          = 5.0;

input group "=== Filters ==="
input bool   Enable_Trend_Filter       = true;
input int    Trend_MA_Period           = 200;
input bool   Use_News_Filter           = true;
input int    News_Before_Mins          = 30;
input int    News_After_Mins           = 30;
input int    Max_Spread_Points         = 50;
input int    Max_Slippage_Points       = 10;

input group "=== Recovery Mode ==="
input bool   Recovery_Enabled          = true;
input double Recovery_Target_USD       = 50.0;
input int    Overlap_After_X_Trades    = 3;

input group "=== Basket Management ==="
input double Basket_Profit_USD         = 100.0;
input double Basket_Loss_USD           = 50.0;

input group "=== Risk Management ==="
input double Daily_Loss_USD            = 100.0;
input double Daily_Loss_Pct            = 5.0;
input double Equity_DD_Pct             = 10.0;
input double Max_DD_Pct                = 15.0;
input double Daily_Profit_USD          = 200.0;
input int    Stop_After_N_Losses       = 5;

input group "=== Trading Schedule ==="
input bool Monday_Active    = true;  input int Monday_Start    = 0;  input int Monday_End    = 23;
input bool Tuesday_Active   = true;  input int Tuesday_Start   = 0;  input int Tuesday_End   = 23;
input bool Wednesday_Active = true;  input int Wednesday_Start = 0;  input int Wednesday_End = 23;
input bool Thursday_Active  = true;  input int Thursday_Start  = 0;  input int Thursday_End  = 23;
input bool Friday_Active    = true;  input int Friday_Start    = 0;  input int Friday_End    = 20;
input bool Saturday_Active  = false;
input bool Sunday_Active    = false;

input group "=== Stochastic ==="
input int Stoch_K   = 5;
input int Stoch_D   = 3;
input int Stoch_Slw = 3;

input group "=== Display ==="
input bool Enable_History_Labels = true;
input int  History_Labels_Limit  = 50;

//==================================================================
//  MODULE INSTANCES
//==================================================================
CIndicatorCache      g_cache;
CValidator           g_validator;
CSMCDetector         g_smc;
CPriceActionAnalyzer g_pa;
COrderExecutor       g_exec;
CPositionTracker     g_tracker;
CStealthModeManager  g_stealth;
CBasketManager       g_basket;
CPositionSizer       g_sizer;
CTPSLCalculator      g_tpsl;
CTrailingStop        g_trail;
CBreakeven           g_be;
CRiskLimitsMonitor   g_risk;
CRecoveryMode        g_recovery;
CTrendFilter         g_trendF;
CNewsFilter          g_newsF;
CSpreadFilter        g_spreadF;
CScheduleFilter      g_schedF;
CStochasticFilter    g_stochF;
CFilterManager       g_filters;
CSMCStrategy         g_smcStrat;
CBreakoutStrategy    g_boStrat;
CStopHuntStrategy    g_shStrat;
CGridStrategy        g_grid;
CStrategyManager     g_stratMgr;
CHistoryLabels       g_labels;

//--- Global state
RiskMetrics g_rm;
GridConfig  g_gc;
datetime    g_lastBar    = 0;
bool        g_initOk     = false;
bool        g_tradeAllow = false;

#define EA_NAME    "MoneyMachine7"
#define EA_VERSION "1.0.0"

//==================================================================
//  OnInit
//==================================================================
int OnInit()
{
   Logger.Init(LOG_INFO, EA_NAME);
   Logger.Info("==============================================");
   Logger.Info(" "+EA_NAME+" v"+EA_VERSION+" starting");
   Logger.Info(" Symbol: "+_Symbol+"  TF: "+EnumToString(Period()));
   Logger.Info(" Magic:  "+IntegerToString(Magic_Number));
   Logger.Info(" Mode:   "+EnumToString(SMC_Mode));
   Logger.Info("==============================================");

   // [1] Indicators
   if(!g_cache.Init(_Symbol,PERIOD_CURRENT,
                    ATR_Period,Trend_MA_Period,RSI_Period,
                    Stoch_K,Stoch_D,Stoch_Slw,5))
   { Logger.Error("OnInit: Indicator cache failed"); Alert(EA_NAME+": indicator init failed"); return INIT_FAILED; }

   // [2] Validation
   g_validator.Init(_Symbol,(long)Magic_Number);
   if(!g_validator.ValidateAll(Lot,Max_Lot,g_cache))
   { Logger.Error("OnInit: Validation failed"); return INIT_FAILED; }

   // [3] Risk metrics baseline
   g_rm.dailyProfit=0; g_rm.dailyLoss=0; g_rm.consecutiveLosses=0;
   g_rm.maxDrawdown=0; g_rm.currentDrawdown=0;
   g_rm.equityPeak=AccountInfoDouble(ACCOUNT_EQUITY);
   g_rm.lastResetTime=TimeCurrent(); g_rm.tradingAllowed=true;

   // [4] Grid config
   g_gc.intensity=Grid_Intensity; g_gc.maxBuyOrders=Max_Buy; g_gc.maxSellOrders=Max_Sell;
   g_gc.multiplier=Grid_Distance_Multiplier; g_gc.stochFilterEnabled=Use_Grid_Stoch_Filter;
   g_gc.baseDistance=0;

   // [5] Market analysis
   g_smc.Init(_Symbol,FVG_Lookback_Bars,OB_Lookback_Bars,
              Min_FVG_Size_Points,OB_Min_Body_Percent,Draw_FVG_Zones,Draw_OB_Zones);
   g_pa.Init(_Symbol,Swing_Lookback);

   // [6] Position management
   g_exec.Init(_Symbol,(long)Magic_Number,Comment_Text,Max_Slippage_Points);
   g_tracker.Init((long)Magic_Number,Control_orders_user);

   // [7] Risk calculations
   g_sizer.Init(_Symbol,Use_Dynamic_Lot,Lot,Free_Margin_Per_Lot,Max_Lot,Kmartin);
   g_tpsl.Init(_Symbol,Use_Auto_TP,Auto_TP_Ratio,Use_Auto_SL,Auto_SL_Ratio,Use_Stealth_Mode,g_cache);

   // [8] Per-tick risk managers
   g_stealth.Init(Use_Stealth_Mode,_Symbol,g_tracker,g_exec);
   g_trail.Init(Enable_TrailingStop,Use_Stealth_Mode,_Symbol,
                TS_Start_ATR_Mult,TS_Distance_ATR_Mult,g_cache,g_tracker,g_exec);
   g_be.Init(Enable_Breakeven,Use_Stealth_Mode,_Symbol,
             BE_Trigger_ATR_Mult,BE_Profit_Points,g_cache,g_tracker,g_exec);
   g_risk.Init(Daily_Loss_USD,Daily_Loss_Pct,Equity_DD_Pct,Max_DD_Pct,
               Daily_Profit_USD,Stop_After_N_Losses,g_rm);
   g_basket.Init(Basket_Profit_USD,Basket_Loss_USD,g_tracker,g_exec);
   g_recovery.Init(Recovery_Enabled,Recovery_Target_USD,Overlap_After_X_Trades,g_tracker,g_exec);

   // [9] Filters
   g_trendF.Init(Enable_Trend_Filter,_Symbol,g_cache);
   g_newsF.Init(Use_News_Filter,_Symbol,News_Before_Mins,News_After_Mins);
   g_spreadF.Init(_Symbol,Max_Spread_Points);
   g_schedF.Init(Monday_Active,   Monday_Start,   Monday_End,
                 Tuesday_Active,  Tuesday_Start,  Tuesday_End,
                 Wednesday_Active,Wednesday_Start,Wednesday_End,
                 Thursday_Active, Thursday_Start, Thursday_End,
                 Friday_Active,   Friday_Start,   Friday_End,
                 Saturday_Active, Sunday_Active);
   g_stochF.Init(Use_Grid_Stoch_Filter,Stoch_Buy_Level,Stoch_Sell_Level,g_cache);
   g_filters.Init(g_trendF,g_newsF,g_spreadF,g_schedF,g_stochF);

   // [10] Strategies
   g_smcStrat.Init(true,_Symbol,SMC_Mode,Hunt_Confirm_Pts,Swing_Lookback,
                   RSI_Buy_Threshold,RSI_Sell_Threshold,g_smc,g_pa,g_cache);
   g_boStrat.Init(Enable_Breakout,_Symbol,Breakout_Period,Breakout_Buffer_Pts,Min_Breakout_Range_Pts,
                  Use_RSI_Confirm,RSI_Buy_Threshold,RSI_Sell_Threshold,
                  Use_Volume_Confirm,Volume_MA_Period,g_pa,g_cache);
   g_shStrat.Init(Enable_StopHunt,_Symbol,Swing_Lookback,Hunt_Confirm_Pts,g_smc,g_pa);
   g_grid.Init(_Symbol,Grid_Intensity,ADR_Period_Days,Grid_Distance_Multiplier,Custom_ADR_Divider,
               Max_Buy,Max_Sell,g_pa,g_cache,g_tracker,g_exec,g_sizer,g_tpsl,g_filters);
   g_stratMgr.Init(SMC_Mode,g_smcStrat,g_boStrat,g_shStrat);

   // [11] Display
   g_labels.Init(Enable_History_Labels,History_Labels_Limit,(long)Magic_Number);

   // Done
   g_initOk=true; g_tradeAllow=true; g_lastBar=0;
   Logger.Info("==============================================");
   Logger.Info(" "+EA_NAME+" init SUCCESSFUL");
   Logger.Info(" Equity: "+DoubleToString(g_rm.equityPeak,2)+" USD");
   Logger.Info("==============================================");
   return INIT_SUCCEEDED;
}

//==================================================================
//  OnTick
//==================================================================
void OnTick()
{
   if(!g_initOk) return;

   //--- EVERY TICK ---
   g_cache.UpdateIndicators();
   g_tracker.UpdatePositions();

   // Risk gate (updates g_tradeAllow)
   g_tradeAllow = g_risk.CheckRiskLimits();

   // Position management – always runs to protect open trades
   g_stealth.ManageStealthMode();
   g_trail.UpdateAll();
   g_be.UpdateAll();
   g_basket.ManageBasket();
   g_recovery.ManageRecovery();

   if(!g_tradeAllow) return;

   //--- NEW BAR GATE ---
   datetime barTime = iTime(_Symbol,PERIOD_CURRENT,0);
   if(barTime == g_lastBar) return;
   g_lastBar = barTime;

   // Per-bar analysis
   g_smc.RunFullDetection();
   g_filters.Update();
   g_labels.DrawHistoryLabels();

   // Grid (self-contained)
   g_grid.PlaceGridOrders();

   // Directional signal
   SignalResult sig = g_stratMgr.GetBestSignal();
   if(sig.type == SIGNAL_NONE) return;

   ENUM_ORDER_TYPE   otype = (sig.type==SIGNAL_BUY) ? ORDER_TYPE_BUY   : ORDER_TYPE_SELL;
   ENUM_POSITION_TYPE ptype= (sig.type==SIGNAL_BUY) ? POSITION_TYPE_BUY: POSITION_TYPE_SELL;

   // Recovery overlap gate
   if(!g_recovery.IsNewPositionAllowed(ptype))
   { Logger.Debug("OnTick: blocked by recovery overlap"); return; }

   // Filter chain
   if(!g_filters.ApplyFilters(otype,false))
   { Logger.Debug("OnTick: "+g_filters.GetLastRejectionReason()); return; }

   // Lot size
   double lots = g_sizer.CalculateLotSize(0);
   if(lots<=0){ Logger.Warning("OnTick: lots=0"); return; }

   // TP/SL levels
   double entry = (otype==ORDER_TYPE_BUY)
                  ? SymbolInfoDouble(_Symbol,SYMBOL_ASK)
                  : SymbolInfoDouble(_Symbol,SYMBOL_BID);
   TPSLResult lv = g_tpsl.Calculate(entry, otype);

   // Execute
   ulong ticket = g_exec.OpenPosition(otype, lots, lv.tp, lv.sl, sig.strategyName);
   if(ticket==0){ Logger.Warning("OnTick: OpenPosition failed"); return; }

   // Register virtual levels
   if(Use_Stealth_Mode && (lv.virtualTP>0 || lv.virtualSL>0))
   {
      g_tracker.UpdatePositions();
      g_tracker.SetVirtualLevels(ticket, lv.virtualTP, lv.virtualSL);
      Logger.Info("OnTick: vTP="+DoubleToString(lv.virtualTP,_Digits)
                  +" vSL="+DoubleToString(lv.virtualSL,_Digits));
   }

   Logger.Info("OnTick: OPENED #"+IntegerToString((int)ticket)
               +" "+(otype==ORDER_TYPE_BUY?"BUY":"SELL")
               +" "+DoubleToString(lots,2)+"lots"
               +" strat="+sig.strategyName+" | "+sig.reason);
}

//==================================================================
//  OnDeinit
//==================================================================
void OnDeinit(const int reason)
{
   Logger.Info("OnDeinit: reason="+IntegerToString(reason));
   Logger.Info("--- Session Summary ---");
   Logger.Info(" DailyProfit   : "+DoubleToString(g_rm.dailyProfit,2)+" USD");
   Logger.Info(" DailyLoss     : "+DoubleToString(g_rm.dailyLoss,2)+" USD");
   Logger.Info(" MaxDrawdown   : "+DoubleToString(g_rm.maxDrawdown,2)+"%");
   Logger.Info(" ConsecLosses  : "+IntegerToString(g_rm.consecutiveLosses));
   Logger.Info(" OpenPositions : "+IntegerToString(g_tracker.GetTotalCount()));
   Logger.Info(" EquityPeak    : "+DoubleToString(g_rm.equityPeak,2)+" USD");

   if(!Enable_History_Labels) g_labels.RemoveAllLabels();
   g_smc.RemoveChartObjects();
   g_cache.Cleanup();

   Logger.Info("==============================================");
   Logger.Info(" "+EA_NAME+" v"+EA_VERSION+" shutdown complete");
   Logger.Info("==============================================");
}
