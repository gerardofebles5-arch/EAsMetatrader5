//+------------------------------------------------------------------+
//|  StrategyManager.mqh  -  Money Machine 7                         |
//+------------------------------------------------------------------+
#ifndef __MM7_STRATMANAGER__
#define __MM7_STRATMANAGER__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"
#include "SMCStrategy.mqh"
#include "BreakoutStrategy.mqh"
#include "StopHuntStrategy.mqh"

class CStrategyManager
{
private:
   CSMCStrategy*      m_smc;
   CBreakoutStrategy* m_bo;
   CStopHuntStrategy* m_sh;

public:
   CStrategyManager(): m_smc(NULL), m_bo(NULL), m_sh(NULL) {}

   void Init(ENUM_SMC_MODE mode,
             CSMCStrategy &smc, CBreakoutStrategy &bo, CStopHuntStrategy &sh)
   { m_smc=&smc; m_bo=&bo; m_sh=&sh;
     Logger.Info("StrategyManager: Init mode="+EnumToString(mode)); }

   SignalResult GetBestSignal()
   {
      SignalResult best; best.type=SIGNAL_NONE; best.strength=0; best.strategyName=""; best.reason="";

      // StopHunt has highest institutional confidence
      if(m_sh!=NULL && m_sh.IsEnabled())
      { SignalResult s=m_sh.Analyze(); if(s.type!=SIGNAL_NONE && s.strength>best.strength) best=s; }

      if(m_smc!=NULL && m_smc.IsEnabled())
      { SignalResult s=m_smc.Analyze(); if(s.type!=SIGNAL_NONE && s.strength>best.strength) best=s; }

      if(m_bo!=NULL && m_bo.IsEnabled())
      { SignalResult s=m_bo.Analyze(); if(s.type!=SIGNAL_NONE && s.strength>best.strength) best=s; }

      if(best.type!=SIGNAL_NONE)
         Logger.Info("StratManager: "+(best.type==SIGNAL_BUY?"BUY":"SELL")
                     +" from="+best.strategyName+" str="+DoubleToString(best.strength,2)
                     +" | "+best.reason);
      return best;
   }
};

#endif
