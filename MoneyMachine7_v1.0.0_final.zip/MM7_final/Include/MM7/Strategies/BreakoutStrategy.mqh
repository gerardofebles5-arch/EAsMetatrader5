//+------------------------------------------------------------------+
//|  BreakoutStrategy.mqh  -  Money Machine 7                        |
//+------------------------------------------------------------------+
#ifndef __MM7_BREAKOUTSTRAT__
#define __MM7_BREAKOUTSTRAT__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"
#include "..\Market\PriceActionAnalyzer.mqh"
#include "..\Market\IndicatorCache.mqh"

class CBreakoutStrategy
{
private:
   bool                  m_en;
   string                m_sym;
   int                   m_period;
   double                m_bufPts, m_minRange;
   bool                  m_useRSI, m_useVol;
   double                m_rsiBuy, m_rsiSell;
   int                   m_volMA;
   CPriceActionAnalyzer* m_pa;
   CIndicatorCache*      m_cache;

public:
   CBreakoutStrategy(): m_en(false), m_period(50), m_bufPts(0), m_minRange(0),
                        m_useRSI(true), m_useVol(true), m_rsiBuy(50), m_rsiSell(50),
                        m_volMA(20), m_pa(NULL), m_cache(NULL) {}

   void Init(bool en, string sym,
             int period, double bufPts, double minRangePts,
             bool useRSI, double rsiBuy, double rsiSell,
             bool useVol, int volMA,
             CPriceActionAnalyzer &pa, CIndicatorCache &cache)
   {
      m_en=en; m_sym=sym; m_period=period;
      m_bufPts=bufPts*_Point; m_minRange=minRangePts*_Point;
      m_useRSI=useRSI; m_rsiBuy=rsiBuy; m_rsiSell=rsiSell;
      m_useVol=useVol; m_volMA=volMA;
      m_pa=&pa; m_cache=&cache;
      Logger.Info("Breakout: "+(en?"ENABLED":"DISABLED")+" period="+IntegerToString(period));
   }

   SignalResult Analyze()
   {
      SignalResult r; r.type=SIGNAL_NONE; r.strategyName="Breakout"; r.entryPrice=0; r.strength=0; r.reason="";
      if(!m_en) return r;

      double rHi=m_pa.GetHighestHigh(m_period);
      double rLo=m_pa.GetLowestLow(m_period);
      if((rHi-rLo) < m_minRange) return r;

      double cl=iClose(m_sym,PERIOD_CURRENT,1);
      bool bullBrk=(cl > rHi+m_bufPts);
      bool bearBrk=(cl < rLo-m_bufPts);
      if(!bullBrk && !bearBrk) return r;

      ENUM_ORDER_TYPE dir=bullBrk?ORDER_TYPE_BUY:ORDER_TYPE_SELL;

      if(m_useRSI && m_cache!=NULL)
      {
         double rsi=m_cache.GetRSI(0);
         if(bullBrk && rsi<m_rsiBuy)
         { Logger.Debug("Breakout: BUY rejected RSI="+DoubleToString(rsi,1)); return r; }
         if(bearBrk && rsi>m_rsiSell)
         { Logger.Debug("Breakout: SELL rejected RSI="+DoubleToString(rsi,1)); return r; }
      }
      if(m_useVol && !m_pa.IsVolumeAboveMA(m_volMA))
      { Logger.Debug("Breakout: rejected volume below MA"); return r; }

      r.type     = bullBrk?SIGNAL_BUY:SIGNAL_SELL;
      r.reason   = (bullBrk?"Bull":"Bear")+" breakout"
                   +(m_useRSI?"+RSI":"")+(m_useVol?"+Vol":"");
      r.strength = 0.80;
      Logger.Debug("Breakout: "+(r.type==SIGNAL_BUY?"BUY":"SELL")+" "+r.reason);
      return r;
   }

   string GetName()   const { return "Breakout"; }
   bool   IsEnabled() const { return m_en; }
};

#endif
