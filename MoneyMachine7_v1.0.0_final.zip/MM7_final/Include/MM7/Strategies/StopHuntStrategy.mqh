//+------------------------------------------------------------------+
//|  StopHuntStrategy.mqh  -  Money Machine 7                        |
//+------------------------------------------------------------------+
#ifndef __MM7_STOPHUNTSTRAT__
#define __MM7_STOPHUNTSTRAT__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"
#include "..\Market\SMCDetector.mqh"
#include "..\Market\PriceActionAnalyzer.mqh"

class CStopHuntStrategy
{
private:
   bool                  m_en;
   string                m_sym;
   int                   m_lb;
   double                m_confirmPts;
   CSMCDetector*         m_det;
   CPriceActionAnalyzer* m_pa;

public:
   CStopHuntStrategy(): m_en(false), m_lb(50), m_confirmPts(0),
                        m_det(NULL), m_pa(NULL) {}

   void Init(bool en, string sym, int lb, double confirmPts,
             CSMCDetector &det, CPriceActionAnalyzer &pa)
   {
      m_en=en; m_sym=sym; m_lb=lb;
      m_confirmPts=confirmPts*_Point;
      m_det=&det; m_pa=&pa;
      Logger.Info("StopHunt: "+(en?"ENABLED":"DISABLED")+" lb="+IntegerToString(lb));
   }

   SignalResult Analyze()
   {
      SignalResult r; r.type=SIGNAL_NONE; r.strategyName="StopHunt"; r.entryPrice=0; r.strength=0; r.reason="";
      if(!m_en) return r;

      double sh=m_pa.FindLastSwingHigh(m_lb);
      double sl=m_pa.FindLastSwingLow(m_lb);
      double h1=iHigh(m_sym,PERIOD_CURRENT,1);
      double l1=iLow(m_sym,PERIOD_CURRENT,1);
      double c1=iClose(m_sym,PERIOD_CURRENT,1);

      if(sh>0 && h1>sh+m_confirmPts && c1<sh)
      {
         r.type=SIGNAL_SELL; r.reason="BearSweep+OBreversal"; r.strength=0.88;
         Logger.Debug("StopHunt: SELL sh="+DoubleToString(sh,_Digits));
         return r;
      }
      if(sl>0 && l1<sl-m_confirmPts && c1>sl)
      {
         r.type=SIGNAL_BUY; r.reason="BullSweep+OBreversal"; r.strength=0.88;
         Logger.Debug("StopHunt: BUY sl="+DoubleToString(sl,_Digits));
         return r;
      }
      return r;
   }

   string GetName()   const { return "StopHunt"; }
   bool   IsEnabled() const { return m_en; }
};

#endif
