//+------------------------------------------------------------------+
//|  SMCStrategy.mqh  -  Money Machine 7                             |
//+------------------------------------------------------------------+
#ifndef __MM7_SMCSTRATEGY__
#define __MM7_SMCSTRATEGY__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"
#include "..\Market\SMCDetector.mqh"
#include "..\Market\PriceActionAnalyzer.mqh"
#include "..\Market\IndicatorCache.mqh"

class CSMCStrategy
{
private:
   bool                  m_en;
   string                m_sym;
   ENUM_SMC_MODE         m_mode;
   double                m_huntPts;
   int                   m_swingLB;
   double                m_rsiBuy, m_rsiSell;
   CSMCDetector*         m_det;
   CPriceActionAnalyzer* m_pa;
   CIndicatorCache*      m_cache;

   bool DetectHunt(ENUM_ORDER_TYPE &dir)
   {
      double cd=m_huntPts*_Point;
      double sh=m_pa.FindLastSwingHigh(m_swingLB);
      double sl=m_pa.FindLastSwingLow(m_swingLB);
      double h1=iHigh(m_sym,PERIOD_CURRENT,1);
      double l1=iLow(m_sym,PERIOD_CURRENT,1);
      double c1=iClose(m_sym,PERIOD_CURRENT,1);
      if(sh>0 && h1>sh && c1<sh-cd){ dir=ORDER_TYPE_SELL; return true; }
      if(sl>0 && l1<sl && c1>sl+cd){ dir=ORDER_TYPE_BUY;  return true; }
      return false;
   }

   bool HasOB(ENUM_ORDER_TYPE d)
   {
      double bid=SymbolInfoDouble(m_sym,SYMBOL_BID);
      double atr=(m_cache!=NULL)?m_cache.GetATR(0):0;
      double z=(atr>0)?atr*0.5:20*_Point;
      return m_det.IsPriceInOrderBlock(bid,d)
          || m_det.IsPriceInOrderBlock(bid+z,d)
          || m_det.IsPriceInOrderBlock(bid-z,d);
   }

   bool HasBOS(ENUM_ORDER_TYPE d) { BreakOfStructure b; return m_det.GetLastBOS(d,b); }

   bool RSIOk(ENUM_ORDER_TYPE d)
   {
      if(m_cache==NULL) return true;
      double r=m_cache.GetRSI(0);
      if(d==ORDER_TYPE_BUY)  return r>=m_rsiBuy;
      if(d==ORDER_TYPE_SELL) return r<=m_rsiSell;
      return true;
   }

public:
   CSMCStrategy(): m_en(false), m_mode(SMC_HYBRID), m_huntPts(5),
                   m_swingLB(50), m_rsiBuy(50), m_rsiSell(50),
                   m_det(NULL), m_pa(NULL), m_cache(NULL) {}

   void Init(bool en, string sym, ENUM_SMC_MODE mode,
             double huntPts, int swingLB, double rsiBuy, double rsiSell,
             CSMCDetector &det, CPriceActionAnalyzer &pa, CIndicatorCache &cache)
   {
      m_en=en; m_sym=sym; m_mode=mode; m_huntPts=huntPts; m_swingLB=swingLB;
      m_rsiBuy=rsiBuy; m_rsiSell=rsiSell;
      m_det=&det; m_pa=&pa; m_cache=&cache;
      Logger.Info("SMCStrategy: "+(en?"ENABLED":"DISABLED")+" mode="+EnumToString(mode));
   }

   SignalResult Analyze()
   {
      SignalResult r; r.type=SIGNAL_NONE; r.strategyName="SMC"; r.entryPrice=0; r.strength=0; r.reason="";
      if(!m_en) return r;

      ENUM_ORDER_TYPE huntDir;
      double bid=SymbolInfoDouble(m_sym,SYMBOL_BID);

      switch(m_mode)
      {
         case SMC_SWEEP:
            if(DetectHunt(huntDir) && HasOB(huntDir))
            { r.type=(huntDir==ORDER_TYPE_BUY)?SIGNAL_BUY:SIGNAL_SELL;
              r.reason="Sweep+OB"; r.strength=0.85; }
            break;

         case SMC_BREAKOUT:
            if(HasBOS(ORDER_TYPE_BUY) && RSIOk(ORDER_TYPE_BUY))
            { r.type=SIGNAL_BUY; r.reason="BullBOS+RSI"; r.strength=0.75; }
            else if(HasBOS(ORDER_TYPE_SELL) && RSIOk(ORDER_TYPE_SELL))
            { r.type=SIGNAL_SELL; r.reason="BearBOS+RSI"; r.strength=0.75; }
            break;

         case SMC_HYBRID: default:
            if(DetectHunt(huntDir) && HasOB(huntDir))
            { r.type=(huntDir==ORDER_TYPE_BUY)?SIGNAL_BUY:SIGNAL_SELL; r.reason="Hybrid:Sweep"; r.strength=0.90; break; }
            if(m_det.IsPriceInFVG(bid,ORDER_TYPE_BUY))
            { r.type=SIGNAL_BUY;  r.reason="Hybrid:BullFVG"; r.strength=0.70; }
            else if(m_det.IsPriceInFVG(bid,ORDER_TYPE_SELL))
            { r.type=SIGNAL_SELL; r.reason="Hybrid:BearFVG"; r.strength=0.70; }
            else if(HasBOS(ORDER_TYPE_BUY))
            { r.type=SIGNAL_BUY;  r.reason="Hybrid:BullBOS"; r.strength=0.60; }
            else if(HasBOS(ORDER_TYPE_SELL))
            { r.type=SIGNAL_SELL; r.reason="Hybrid:BearBOS"; r.strength=0.60; }
            break;
      }

      if(r.type!=SIGNAL_NONE)
         Logger.Debug("SMC: "+(r.type==SIGNAL_BUY?"BUY":"SELL")+" "+r.reason+" str="+DoubleToString(r.strength,2));
      return r;
   }

   string GetName()    const { return "SMC"; }
   bool   IsEnabled()  const { return m_en; }
};

#endif
