//+------------------------------------------------------------------+
//|  GridStrategy.mqh  -  Money Machine 7                            |
//+------------------------------------------------------------------+
#ifndef __MM7_GRIDSTRAT__
#define __MM7_GRIDSTRAT__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"
#include "..\Market\PriceActionAnalyzer.mqh"
#include "..\Market\IndicatorCache.mqh"
#include "..\Position\PositionTracker.mqh"
#include "..\Position\OrderExecutor.mqh"
#include "..\Risk\PositionSizer.mqh"
#include "..\Risk\TPSLCalculator.mqh"
#include "..\Filters\FilterManager.mqh"

class CGridStrategy
{
private:
   bool                  m_en;
   string                m_sym;
   int                   m_intensity, m_adrDays;
   double                m_distMult, m_adrDiv;
   int                   m_maxBuy, m_maxSell;
   int                   m_digits;
   CPriceActionAnalyzer* m_pa;
   CPositionTracker*     m_tracker;
   COrderExecutor*       m_exec;
   CPositionSizer*       m_sizer;
   CTPSLCalculator*      m_tpsl;
   CFilterManager*       m_filters;

   double GetDivisor()
   {
      switch(m_intensity){ case 1:return 1500; case 3:return 1000; default:return 1200; }
   }

   double CalcGridDist()
   {
      double adr=m_pa.CalculateADR(m_adrDays);
      if(adr<=0) adr=20.0*_Point*100;
      double d=(adr/GetDivisor())*m_distMult;
      if(m_adrDiv>0 && m_adrDiv!=1.0) d/=m_adrDiv;
      return d;
   }

   bool HasNearby(double price, double tol)
   {
      int n=m_tracker.GetTotalCount();
      for(int i=0;i<n;i++)
      { PositionInfo p; if(m_tracker.GetByIndex(i,p) && MathAbs(p.openPrice-price)<tol) return true; }
      return false;
   }

public:
   CGridStrategy(): m_en(false), m_intensity(2), m_adrDays(14),
                    m_distMult(1), m_adrDiv(1), m_maxBuy(5), m_maxSell(5), m_digits(5),
                    m_pa(NULL), m_tracker(NULL), m_exec(NULL),
                    m_sizer(NULL), m_tpsl(NULL), m_filters(NULL) {}

   void Init(string sym, int intensity, int adrDays,
             double distMult, double adrDiv, int maxBuy, int maxSell,
             CPriceActionAnalyzer &pa, CIndicatorCache &cache,
             CPositionTracker &tracker, COrderExecutor &exec,
             CPositionSizer &sizer, CTPSLCalculator &tpsl, CFilterManager &filters)
   {
      m_en=(intensity>0); m_sym=sym; m_intensity=intensity; m_adrDays=adrDays;
      m_distMult=distMult; m_adrDiv=adrDiv; m_maxBuy=maxBuy; m_maxSell=maxSell;
      m_digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
      m_pa=&pa; m_tracker=&tracker; m_exec=&exec;
      m_sizer=&sizer; m_tpsl=&tpsl; m_filters=&filters;
      Logger.Info("Grid: "+(m_en?"ENABLED":"DISABLED")+" intensity="+IntegerToString(intensity)
                  +" maxBuy="+IntegerToString(maxBuy)+" maxSell="+IntegerToString(maxSell));
   }

   void PlaceGridOrders()
   {
      if(!m_en) return;
      double dist=CalcGridDist();
      if(dist<=0) return;

      double ask=SymbolInfoDouble(m_sym,SYMBOL_ASK);
      double bid=SymbolInfoDouble(m_sym,SYMBOL_BID);
      double mid=(ask+bid)/2.0;
      double tol=dist*0.3;
      int gridN=m_tracker.GetBuyCount()+m_tracker.GetSellCount();

      // BUY grid below mid
      if(m_tracker.GetBuyCount()<m_maxBuy && m_filters.ApplyFilters(ORDER_TYPE_BUY,true))
      {
         double lvl=NormalizeDouble(mid-dist, m_digits);
         if(!HasNearby(lvl,tol))
         {
            double lots=m_sizer.CalculateLotSize(gridN);
            TPSLResult lv=m_tpsl.Calculate(lvl, ORDER_TYPE_BUY);
            ulong t=m_exec.OpenPosition(ORDER_TYPE_BUY, lots, lv.tp, lv.sl, "Grid");
            if(t>0 && lv.virtualTP>0) m_tracker.SetVirtualLevels(t, lv.virtualTP, lv.virtualSL);
         }
      }

      // SELL grid above mid
      if(m_tracker.GetSellCount()<m_maxSell && m_filters.ApplyFilters(ORDER_TYPE_SELL,true))
      {
         double lvl=NormalizeDouble(mid+dist, m_digits);
         if(!HasNearby(lvl,tol))
         {
            double lots=m_sizer.CalculateLotSize(gridN);
            TPSLResult lv=m_tpsl.Calculate(lvl, ORDER_TYPE_SELL);
            ulong t=m_exec.OpenPosition(ORDER_TYPE_SELL, lots, lv.tp, lv.sl, "Grid");
            if(t>0 && lv.virtualTP>0) m_tracker.SetVirtualLevels(t, lv.virtualTP, lv.virtualSL);
         }
      }
   }

   bool   IsEnabled() const { return m_en; }
   string GetName()   const { return "Grid"; }
};

#endif
