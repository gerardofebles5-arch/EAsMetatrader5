//+------------------------------------------------------------------+
//|  SMCDetector.mqh  -  Money Machine 7                             |
//+------------------------------------------------------------------+
#ifndef __MM7_SMCDETECTOR__
#define __MM7_SMCDETECTOR__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"

class CSMCDetector
{
private:
   string   m_sym;
   int      m_fvgLB, m_obLB;
   double   m_minFVG, m_obBodyPct;
   bool     m_drawFVG, m_drawOB;
   int      m_objCnt;

   OrderBlock       m_ob[];
   FairValueGap     m_fvg[];
   BreakOfStructure m_bos[];

   void DrawRect(string nm, datetime t1, double p1, datetime t2, double p2, color c)
   {
      if(ObjectFind(0,nm)>=0) ObjectDelete(0,nm);
      ObjectCreate(0,nm,OBJ_RECTANGLE,0,t1,p1,t2,p2);
      ObjectSetInteger(0,nm,OBJPROP_COLOR,c);
      ObjectSetInteger(0,nm,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,nm,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,nm,OBJPROP_FILL,true);
      ObjectSetInteger(0,nm,OBJPROP_BACK,true);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   }
   string UName(string p) { return p+"_"+IntegerToString(m_objCnt++); }

public:
   CSMCDetector(): m_fvgLB(1200),m_obLB(1200),m_minFVG(0),
                   m_obBodyPct(50),m_drawFVG(true),m_drawOB(true),m_objCnt(0) {}

   void Init(string sym,int fvgLB,int obLB,double minFVGPts,double obBodyPct,
             bool drawFVG,bool drawOB)
   {
      m_sym=sym; m_fvgLB=fvgLB; m_obLB=obLB;
      m_minFVG=minFVGPts*_Point; m_obBodyPct=obBodyPct;
      m_drawFVG=drawFVG; m_drawOB=drawOB;
      ArrayResize(m_ob,0); ArrayResize(m_fvg,0); ArrayResize(m_bos,0);
      Logger.Info("SMCDetector: Init fvgLB="+IntegerToString(fvgLB)+" obLB="+IntegerToString(obLB));
   }

   //--- Order Block Detection
   void DetectOrderBlocks()
   {
      int avail=MathMin(m_obLB, Bars(m_sym,PERIOD_CURRENT)-2);
      if(avail<3) return;
      ArrayResize(m_ob,0);

      double avgVol=0;
      for(int i=1;i<=avail;i++) avgVol+=(double)iVolume(m_sym,PERIOD_CURRENT,i);
      avgVol=(avail>0)?avgVol/avail:1;

      for(int i=2;i<=avail-1;i++)
      {
         double o=iOpen(m_sym,PERIOD_CURRENT,i), c=iClose(m_sym,PERIOD_CURRENT,i);
         double h=iHigh(m_sym,PERIOD_CURRENT,i), l=iLow(m_sym,PERIOD_CURRENT,i);
         double rng=h-l;
         if(rng<=0) continue;
         if((MathAbs(c-o)/rng)*100.0 < m_obBodyPct) continue;
         if(iVolume(m_sym,PERIOD_CURRENT,i) < (long)(avgVol*0.8)) continue;

         double cn=iClose(m_sym,PERIOD_CURRENT,i-1);
         int n=ArraySize(m_ob);

         if(c>o && cn<o)
         {
            ArrayResize(m_ob,n+1);
            m_ob[n].priceHigh=h; m_ob[n].priceLow=l;
            m_ob[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_ob[n].direction=ORDER_TYPE_SELL; m_ob[n].isValid=true;
            if(m_drawOB) DrawRect(UName("MM7_OBS"),m_ob[n].time,l,TimeCurrent(),h,(color)0xC8C8FF);
         }
         else if(c<o && cn>o)
         {
            ArrayResize(m_ob,n+1);
            m_ob[n].priceHigh=h; m_ob[n].priceLow=l;
            m_ob[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_ob[n].direction=ORDER_TYPE_BUY; m_ob[n].isValid=true;
            if(m_drawOB) DrawRect(UName("MM7_OBB"),m_ob[n].time,l,TimeCurrent(),h,(color)0xC8FFC8);
         }
      }
      Logger.Debug("SMCDetector: OBs="+IntegerToString(ArraySize(m_ob)));
   }

   //--- Fair Value Gap Detection
   void DetectFairValueGaps()
   {
      int avail=MathMin(m_fvgLB, Bars(m_sym,PERIOD_CURRENT)-2);
      if(avail<3) return;
      ArrayResize(m_fvg,0);

      for(int i=1;i<=avail-1;i++)
      {
         double hP=iHigh(m_sym,PERIOD_CURRENT,i+1), lP=iLow(m_sym,PERIOD_CURRENT,i+1);
         double hN=iHigh(m_sym,PERIOD_CURRENT,i-1), lN=iLow(m_sym,PERIOD_CURRENT,i-1);
         int n=ArraySize(m_fvg);

         if(hP < lN && (lN-hP) >= m_minFVG)
         {
            ArrayResize(m_fvg,n+1);
            m_fvg[n].gapHigh=lN; m_fvg[n].gapLow=hP;
            m_fvg[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_fvg[n].direction=ORDER_TYPE_BUY; m_fvg[n].isFilled=false;
            if(m_drawFVG) DrawRect(UName("MM7_FVG_B"),
                iTime(m_sym,PERIOD_CURRENT,i+1),hP,
                iTime(m_sym,PERIOD_CURRENT,i-1),lN,(color)0xB4FFB4);
         }
         else if(lP > hN && (lP-hN) >= m_minFVG)
         {
            ArrayResize(m_fvg,n+1);
            m_fvg[n].gapHigh=lP; m_fvg[n].gapLow=hN;
            m_fvg[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_fvg[n].direction=ORDER_TYPE_SELL; m_fvg[n].isFilled=false;
            if(m_drawFVG) DrawRect(UName("MM7_FVG_S"),
                iTime(m_sym,PERIOD_CURRENT,i+1),hN,
                iTime(m_sym,PERIOD_CURRENT,i-1),lP,(color)0xFFB4B4);
         }
      }
      Logger.Debug("SMCDetector: FVGs="+IntegerToString(ArraySize(m_fvg)));
   }

   //--- Break of Structure Detection
   void DetectBreakOfStructure()
   {
      int avail=MathMin(m_fvgLB, Bars(m_sym,PERIOD_CURRENT)-3);
      if(avail<5) return;
      ArrayResize(m_bos,0);

      double lastSH=0, lastSL=1.0e15;

      for(int i=avail;i>=2;i--)
      {
         double h=iHigh(m_sym,PERIOD_CURRENT,i), l=iLow(m_sym,PERIOD_CURRENT,i);
         double hP=iHigh(m_sym,PERIOD_CURRENT,i+1), lP=iLow(m_sym,PERIOD_CURRENT,i+1);
         double hN=iHigh(m_sym,PERIOD_CURRENT,i-1), lN=iLow(m_sym,PERIOD_CURRENT,i-1);
         if(h>hP && h>hN) lastSH=h;
         if(l<lP && l<lN) lastSL=l;

         double cl=iClose(m_sym,PERIOD_CURRENT,i);
         int n=ArraySize(m_bos);

         if(lastSH>0 && cl>lastSH)
         {
            ArrayResize(m_bos,n+1);
            m_bos[n].level=lastSH; m_bos[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_bos[n].direction=ORDER_TYPE_BUY; lastSH=0;
         }
         if(lastSL<1.0e15 && cl<lastSL)
         {
            n=ArraySize(m_bos);
            ArrayResize(m_bos,n+1);
            m_bos[n].level=lastSL; m_bos[n].time=iTime(m_sym,PERIOD_CURRENT,i);
            m_bos[n].direction=ORDER_TYPE_SELL; lastSL=1.0e15;
         }
      }
      Logger.Debug("SMCDetector: BOS="+IntegerToString(ArraySize(m_bos)));
   }

   void InvalidateOldStructures()
   {
      double bid=SymbolInfoDouble(m_sym,SYMBOL_BID);
      for(int i=0;i<ArraySize(m_ob);i++)
      {
         if(!m_ob[i].isValid) continue;
         if(m_ob[i].direction==ORDER_TYPE_BUY  && bid<m_ob[i].priceLow)  m_ob[i].isValid=false;
         if(m_ob[i].direction==ORDER_TYPE_SELL && bid>m_ob[i].priceHigh) m_ob[i].isValid=false;
      }
      for(int i=0;i<ArraySize(m_fvg);i++)
         if(!m_fvg[i].isFilled && bid>=m_fvg[i].gapLow && bid<=m_fvg[i].gapHigh)
            m_fvg[i].isFilled=true;
   }

   void RunFullDetection()
   {
      DetectOrderBlocks();
      DetectFairValueGaps();
      DetectBreakOfStructure();
      InvalidateOldStructures();
   }

   bool IsPriceInFVG(double price, ENUM_ORDER_TYPE dir)
   {
      for(int i=0;i<ArraySize(m_fvg);i++)
         if(!m_fvg[i].isFilled && m_fvg[i].direction==dir &&
            price>=m_fvg[i].gapLow && price<=m_fvg[i].gapHigh) return true;
      return false;
   }

   bool IsPriceInOrderBlock(double price, ENUM_ORDER_TYPE dir)
   {
      for(int i=0;i<ArraySize(m_ob);i++)
         if(m_ob[i].isValid && m_ob[i].direction==dir &&
            price>=m_ob[i].priceLow && price<=m_ob[i].priceHigh) return true;
      return false;
   }

   bool GetLastBOS(ENUM_ORDER_TYPE dir, BreakOfStructure &res)
   {
      for(int i=ArraySize(m_bos)-1;i>=0;i--)
         if(m_bos[i].direction==dir){ res=m_bos[i]; return true; }
      return false;
   }

   void RemoveChartObjects()
   {
      for(int i=ObjectsTotal(0)-1;i>=0;i--)
      {
         string nm=ObjectName(0,i);
         if(StringFind(nm,"MM7_OB")>=0||StringFind(nm,"MM7_FVG")>=0) ObjectDelete(0,nm);
      }
   }

   int GetOBCount()  const { return ArraySize(m_ob);  }
   int GetFVGCount() const { return ArraySize(m_fvg); }
   int GetBOSCount() const { return ArraySize(m_bos); }
};

#endif
