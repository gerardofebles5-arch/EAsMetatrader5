//+------------------------------------------------------------------+
//|  IndicatorCache.mqh  -  Money Machine 7                          |
//+------------------------------------------------------------------+
#ifndef __MM7_INDICATORCACHE__
#define __MM7_INDICATORCACHE__

#include "..\Utils\Logger.mqh"

class CIndicatorCache
{
private:
   int      m_hATR, m_hMA, m_hRSI, m_hStoch;
   double   m_atr[], m_ma[], m_rsi[], m_stMain[], m_stSig[];
   datetime m_lastBar;
   int      m_depth;
   bool     m_ok;

   bool CopyBuf(int h, int buf, double &arr[], int n)
   {
      return CopyBuffer(h, buf, 0, n, arr) >= n;
   }

public:
   CIndicatorCache(): m_hATR(INVALID_HANDLE), m_hMA(INVALID_HANDLE),
                      m_hRSI(INVALID_HANDLE), m_hStoch(INVALID_HANDLE),
                      m_lastBar(0), m_depth(5), m_ok(false) {}

   bool Init(string sym, ENUM_TIMEFRAMES tf,
             int atrP, int maP, int rsiP,
             int stK, int stD, int stSlow, int depth=5)
   {
      m_depth = depth;
      m_hATR   = iATR(sym, tf, atrP);
      m_hMA    = iMA(sym, tf, maP, 0, MODE_SMA, PRICE_CLOSE);
      m_hRSI   = iRSI(sym, tf, rsiP, PRICE_CLOSE);
      m_hStoch = iStochastic(sym, tf, stK, stD, stSlow, MODE_SMA, STO_LOWHIGH);

      if(m_hATR==INVALID_HANDLE || m_hMA==INVALID_HANDLE ||
         m_hRSI==INVALID_HANDLE || m_hStoch==INVALID_HANDLE)
      { Logger.Error("IndicatorCache: handle creation failed"); return false; }

      ArraySetAsSeries(m_atr,    true);
      ArraySetAsSeries(m_ma,     true);
      ArraySetAsSeries(m_rsi,    true);
      ArraySetAsSeries(m_stMain, true);
      ArraySetAsSeries(m_stSig,  true);

      m_ok = true;
      Logger.Info("IndicatorCache: OK  ATR="+IntegerToString(atrP)
                  +" MA="+IntegerToString(maP)+" RSI="+IntegerToString(rsiP));
      return true;
   }

   bool UpdateIndicators(bool force=false)
   {
      if(!m_ok) return false;
      datetime t = iTime(_Symbol, PERIOD_CURRENT, 0);
      if(!force && t == m_lastBar) return true;

      bool ok = CopyBuf(m_hATR,   0, m_atr,    m_depth)
             && CopyBuf(m_hMA,    0, m_ma,     m_depth)
             && CopyBuf(m_hRSI,   0, m_rsi,    m_depth)
             && CopyBuf(m_hStoch, 0, m_stMain, m_depth)
             && CopyBuf(m_hStoch, 1, m_stSig,  m_depth);
      if(ok) m_lastBar = t;
      return ok;
   }

   double GetATR      (int s=0){ return(s<ArraySize(m_atr))    ? m_atr[s]    : 0;  }
   double GetMA       (int s=0){ return(s<ArraySize(m_ma))     ? m_ma[s]     : 0;  }
   double GetRSI      (int s=0){ return(s<ArraySize(m_rsi))    ? m_rsi[s]    : 50; }
   double GetStochMain(int s=0){ return(s<ArraySize(m_stMain)) ? m_stMain[s] : 50; }
   double GetStochSig (int s=0){ return(s<ArraySize(m_stSig))  ? m_stSig[s]  : 50; }

   bool AreHandlesValid() const
   { return m_hATR!=INVALID_HANDLE && m_hMA!=INVALID_HANDLE &&
            m_hRSI!=INVALID_HANDLE && m_hStoch!=INVALID_HANDLE; }
   bool IsReady() const { return m_ok; }

   void Cleanup()
   {
      if(m_hATR  !=INVALID_HANDLE){ IndicatorRelease(m_hATR);   m_hATR=INVALID_HANDLE; }
      if(m_hMA   !=INVALID_HANDLE){ IndicatorRelease(m_hMA);    m_hMA=INVALID_HANDLE;  }
      if(m_hRSI  !=INVALID_HANDLE){ IndicatorRelease(m_hRSI);   m_hRSI=INVALID_HANDLE; }
      if(m_hStoch!=INVALID_HANDLE){ IndicatorRelease(m_hStoch); m_hStoch=INVALID_HANDLE; }
      m_ok=false;
      Logger.Info("IndicatorCache: Released");
   }
};

#endif
