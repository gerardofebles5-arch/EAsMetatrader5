//+------------------------------------------------------------------+
//|  PriceActionAnalyzer.mqh  -  Money Machine 7                     |
//+------------------------------------------------------------------+
#ifndef __MM7_PRICEACTION__
#define __MM7_PRICEACTION__

#include "..\Utils\Logger.mqh"

class CPriceActionAnalyzer
{
private:
   string m_sym;
   int    m_swingLB;

public:
   CPriceActionAnalyzer(): m_swingLB(50) {}

   void Init(string sym, int swingLB)
   { m_sym=sym; m_swingLB=swingLB;
     Logger.Info("PriceAction: Init swingLB="+IntegerToString(swingLB)); }

   bool IsSwingHigh(int s)
   {
      if(s<1) return false;
      double h=iHigh(m_sym,PERIOD_CURRENT,s);
      return h>iHigh(m_sym,PERIOD_CURRENT,s+1) && h>iHigh(m_sym,PERIOD_CURRENT,s-1);
   }
   bool IsSwingLow(int s)
   {
      if(s<1) return false;
      double l=iLow(m_sym,PERIOD_CURRENT,s);
      return l<iLow(m_sym,PERIOD_CURRENT,s+1) && l<iLow(m_sym,PERIOD_CURRENT,s-1);
   }

   double FindLastSwingHigh(int lb=0)
   {
      int sc=(lb>0)?lb:m_swingLB;
      for(int i=2;i<=sc;i++) if(IsSwingHigh(i)) return iHigh(m_sym,PERIOD_CURRENT,i);
      return 0;
   }
   double FindLastSwingLow(int lb=0)
   {
      int sc=(lb>0)?lb:m_swingLB;
      for(int i=2;i<=sc;i++) if(IsSwingLow(i)) return iLow(m_sym,PERIOD_CURRENT,i);
      return 0;
   }

   double GetHighestHigh(int bars)
   {
      double r=0;
      for(int i=1;i<=bars;i++){ double h=iHigh(m_sym,PERIOD_CURRENT,i); if(h>r) r=h; }
      return r;
   }
   double GetLowestLow(int bars)
   {
      double r=1.0e15;
      for(int i=1;i<=bars;i++){ double l=iLow(m_sym,PERIOD_CURRENT,i); if(l<r) r=l; }
      return (r>=1.0e15)?0:r;
   }
   double GetRange(int bars) { return GetHighestHigh(bars)-GetLowestLow(bars); }

   double CalculateADR(int days)
   {
      if(days<=0) return 0;
      double sum=0; int cnt=0;
      for(int i=1;i<=days;i++)
      {
         double h=iHigh(m_sym,PERIOD_D1,i), l=iLow(m_sym,PERIOD_D1,i);
         if(h>0&&l>0&&h>l){ sum+=(h-l); cnt++; }
      }
      return cnt>0?sum/cnt:0;
   }

   double GetVolumeMA(int period)
   {
      if(period<=0) return 0;
      double s=0;
      for(int i=1;i<=period;i++) s+=(double)iVolume(m_sym,PERIOD_CURRENT,i);
      return s/period;
   }
   bool IsVolumeAboveMA(int period)
   {
      double vma=GetVolumeMA(period);
      return vma>0 && (double)iVolume(m_sym,PERIOD_CURRENT,1)>vma;
   }

   bool IsBullish(int s){ return iClose(m_sym,PERIOD_CURRENT,s)>iOpen(m_sym,PERIOD_CURRENT,s); }
   bool IsBearish(int s){ return iClose(m_sym,PERIOD_CURRENT,s)<iOpen(m_sym,PERIOD_CURRENT,s); }
   double CandleBody (int s){ return MathAbs(iClose(m_sym,PERIOD_CURRENT,s)-iOpen(m_sym,PERIOD_CURRENT,s)); }
   double CandleRange(int s){ return iHigh(m_sym,PERIOD_CURRENT,s)-iLow(m_sym,PERIOD_CURRENT,s); }
};

#endif
