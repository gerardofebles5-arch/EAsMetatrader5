//+------------------------------------------------------------------+
//|  Validator.mqh  -  Money Machine 7                               |
//+------------------------------------------------------------------+
#ifndef __MM7_VALIDATOR__
#define __MM7_VALIDATOR__

#include "..\Utils\Logger.mqh"
#include "..\Market\IndicatorCache.mqh"

class CValidator
{
private:
   string m_sym;
   long   m_magic;

public:
   CValidator(): m_sym(""), m_magic(700000) {}
   void Init(string sym, long magic) { m_sym=sym; m_magic=magic; }

   bool ValidateAll(double cfgLot, double cfgMax, CIndicatorCache &cache)
   {
      bool ok = CheckAutoTrading() & CheckSymbol() & CheckHandles(cache) & CheckLots(cfgLot, cfgMax);
      CheckMagicConflict();
      if(!ok) Alert("MoneyMachine7: Init validation failed – see Experts log");
      return ok;
   }

   bool CheckAutoTrading()
   {
      if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      { Logger.Error("Validator: AutoTrading disabled in Terminal"); return false; }
      if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
      { Logger.Error("Validator: Trade not allowed for EA"); return false; }
      Logger.Info("Validator: AutoTrading OK");
      return true;
   }

   bool CheckSymbol()
   {
      if(!SymbolSelect(m_sym, true))
      { Logger.Error("Validator: Symbol '"+m_sym+"' not in MarketWatch"); return false; }
      if((ENUM_SYMBOL_TRADE_MODE)SymbolInfoInteger(m_sym,SYMBOL_TRADE_MODE)==SYMBOL_TRADE_MODE_DISABLED)
      { Logger.Error("Validator: Trading disabled on '"+m_sym+"'"); return false; }
      Logger.Info("Validator: Symbol OK");
      return true;
   }

   bool CheckHandles(CIndicatorCache &cache)
   {
      if(!cache.AreHandlesValid())
      { Logger.Error("Validator: Invalid indicator handles"); return false; }
      Logger.Info("Validator: Indicator handles OK");
      return true;
   }

   bool CheckLots(double cfgLot, double cfgMax)
   {
      double bMin=SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MIN);
      double bMax=SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MAX);
      if(cfgLot > cfgMax)
      { Logger.Error("Validator: Lot("+DoubleToString(cfgLot,2)+") > MaxLot("+DoubleToString(cfgMax,2)+")"); return false; }
      if(cfgLot < bMin)  Logger.Warning("Validator: Lot < brokerMin "+DoubleToString(bMin,2)+", will use min");
      if(cfgMax > bMax)  Logger.Warning("Validator: MaxLot > brokerMax "+DoubleToString(bMax,2)+", will cap");
      Logger.Info("Validator: Lots OK");
      return true;
   }

   void CheckMagicConflict()
   {
      int n=0;
      for(int i=0;i<PositionsTotal();i++)
      {
         ulong t=PositionGetTicket(i);
         if(PositionSelectByTicket(t) && PositionGetInteger(POSITION_MAGIC)==m_magic) n++;
      }
      if(n>0) Logger.Warning("Validator: "+IntegerToString(n)+" existing positions with Magic="+IntegerToString((int)m_magic));
      else    Logger.Info("Validator: Magic conflict check OK");
   }
};

#endif
