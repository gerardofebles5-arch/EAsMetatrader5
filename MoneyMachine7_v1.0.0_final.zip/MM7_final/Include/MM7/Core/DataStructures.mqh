//+------------------------------------------------------------------+
//|  DataStructures.mqh  -  Money Machine 7                          |
//+------------------------------------------------------------------+
#ifndef __MM7_DATASTRUCTS__
#define __MM7_DATASTRUCTS__

enum ENUM_SMC_MODE    { SMC_SWEEP=0,    SMC_BREAKOUT=1, SMC_HYBRID=2  };
enum ENUM_SIGNAL_TYPE { SIGNAL_NONE=0,  SIGNAL_BUY=1,   SIGNAL_SELL=2 };

struct PositionInfo
{
   ulong              ticket;
   ENUM_POSITION_TYPE type;
   double             openPrice;
   double             currentPrice;
   double             lots;
   double             profit;
   datetime           openTime;
   double             virtualTP;
   double             virtualSL;
   bool               trailingActive;
   bool               breakevenSet;
   string             strategy;
};

struct OrderBlock
{
   double          priceHigh;
   double          priceLow;
   datetime        time;
   ENUM_ORDER_TYPE direction;
   bool            isValid;
};

struct FairValueGap
{
   double          gapHigh;
   double          gapLow;
   datetime        time;
   ENUM_ORDER_TYPE direction;
   bool            isFilled;
};

struct BreakOfStructure
{
   double          level;
   datetime        time;
   ENUM_ORDER_TYPE direction;
};

struct RiskMetrics
{
   double   dailyProfit;
   double   dailyLoss;
   int      consecutiveLosses;
   double   maxDrawdown;
   double   currentDrawdown;
   double   equityPeak;
   datetime lastResetTime;
   bool     tradingAllowed;
};

struct GridConfig
{
   double baseDistance;
   int    intensity;
   int    maxBuyOrders;
   int    maxSellOrders;
   double multiplier;
   bool   stochFilterEnabled;
};

struct SignalResult
{
   ENUM_SIGNAL_TYPE type;
   string           strategyName;
   double           entryPrice;
   string           reason;
   double           strength;
};

struct TPSLResult
{
   double tp;
   double sl;
   double virtualTP;
   double virtualSL;
};

#endif
