//+------------------------------------------------------------------+
//|  StochasticFilter.mqh  -  Money Machine 7                        |
//+------------------------------------------------------------------+
#ifndef __MM7_STOCHFILTER__
#define __MM7_STOCHFILTER__

#include "..\Utils\Logger.mqh"
#include "..\Market\IndicatorCache.mqh"

class CStochasticFilter
{
private:
   bool             m_en;
   double           m_buyLv, m_sellLv;
   CIndicatorCache* m_cache;
   string           m_reason;

public:
   CStochasticFilter(): m_en(false), m_buyLv(20), m_sellLv(80), m_cache(NULL) {}

   void Init(bool en, double buyLv, double sellLv, CIndicatorCache &cache)
   { m_en=en; m_buyLv=buyLv; m_sellLv=sellLv; m_cache=&cache;
     Logger.Info("StochFilter: "+(en?"ENABLED":"DISABLED")
                 +" buy<"+DoubleToString(buyLv,0)+" sell>"+DoubleToString(sellLv,0)); }

   bool IsTradeAllowed(ENUM_ORDER_TYPE type, bool isGrid=false)
   {
      if(!m_en || !isGrid) return true;
      double st=(m_cache!=NULL)?m_cache.GetStochMain(0):50;
      if(type==ORDER_TYPE_BUY && st>m_sellLv)
      { m_reason="StochFilter: BUY blocked stoch="+DoubleToString(st,1)+">"+DoubleToString(m_sellLv,0); return false; }
      if(type==ORDER_TYPE_SELL && st<m_buyLv)
      { m_reason="StochFilter: SELL blocked stoch="+DoubleToString(st,1)+"<"+DoubleToString(m_buyLv,0); return false; }
      return true;
   }
   string GetRejectionReason() const { return m_reason; }
};

#endif
