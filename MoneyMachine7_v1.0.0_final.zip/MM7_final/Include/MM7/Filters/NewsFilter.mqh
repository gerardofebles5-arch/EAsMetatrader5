//+------------------------------------------------------------------+
//|  NewsFilter.mqh  -  Money Machine 7                              |
//|  Uses the built-in MT5 Calendar API (no external include needed) |
//+------------------------------------------------------------------+
#ifndef __MM7_NEWSFILTER__
#define __MM7_NEWSFILTER__

#include "..\Utils\Logger.mqh"

class CNewsFilter
{
private:
   bool     m_en;
   string   m_sym;
   int      m_before, m_after;
   datetime m_suspendUntil;
   bool     m_suspended;
   string   m_reason;

public:
   CNewsFilter(): m_en(false), m_before(30), m_after(30),
                  m_suspendUntil(0), m_suspended(false) {}

   void Init(bool en, string sym, int before, int after)
   {
      m_en=en; m_sym=sym; m_before=before; m_after=after;
      Logger.Info("NewsFilter: "+(en?"ENABLED":"DISABLED")
                  +" before="+IntegerToString(before)+"min after="+IntegerToString(after)+"min");
   }

   // Call once per new bar
   void Update()
   {
      if(!m_en){ m_suspended=false; return; }

      datetime now   = TimeCurrent();
      datetime from  = now - (datetime)(m_after *60);
      datetime to    = now + (datetime)(m_before*60);

      string base  = SymbolInfoString(m_sym, SYMBOL_CURRENCY_BASE);
      string quote = SymbolInfoString(m_sym, SYMBOL_CURRENCY_PROFIT);

      MqlCalendarValue values[];
      int found = CalendarValueHistory(values, from, to);

      m_suspended    = false;
      m_suspendUntil = 0;

      for(int i=0; i<found; i++)
      {
         MqlCalendarEvent ev;
         if(!CalendarEventById(values[i].event_id, ev)) continue;
         if(ev.importance != CALENDAR_IMPORTANCE_HIGH) continue;

         string cur = ev.currency;
         if(cur!=base && cur!=quote) continue;

         datetime evTime = values[i].time;
         datetime susEnd = evTime + (datetime)(m_after*60);

         if(now>=from && now<=susEnd)
         {
            m_suspended    = true;
            m_suspendUntil = susEnd;
            Logger.Warning("NewsFilter: HIGH event "+ev.name+" ("+cur+")"
                           +" @"+TimeToString(evTime,TIME_DATE|TIME_MINUTES)
                           +" – suspended until "+TimeToString(susEnd,TIME_DATE|TIME_MINUTES));
            return;
         }
      }
   }

   bool IsTradeAllowed(ENUM_ORDER_TYPE type)
   {
      if(!m_en || !m_suspended) return true;
      m_reason="NewsFilter: suspended until "+TimeToString(m_suspendUntil,TIME_DATE|TIME_MINUTES);
      return false;
   }

   bool     IsSuspended()          const { return m_suspended; }
   datetime GetResumeTime()        const { return m_suspendUntil; }
   string   GetRejectionReason()   const { return m_reason; }
};

#endif
