//+------------------------------------------------------------------+
//|  FilterManager.mqh  -  Money Machine 7                           |
//+------------------------------------------------------------------+
#ifndef __MM7_FILTERMANAGER__
#define __MM7_FILTERMANAGER__

#include "..\Utils\Logger.mqh"
#include "TrendFilter.mqh"
#include "NewsFilter.mqh"
#include "SpreadFilter.mqh"
#include "ScheduleFilter.mqh"
#include "StochasticFilter.mqh"

class CFilterManager
{
private:
   CTrendFilter*      m_trend;
   CNewsFilter*       m_news;
   CSpreadFilter*     m_spread;
   CScheduleFilter*   m_sched;
   CStochasticFilter* m_stoch;
   string             m_reason;

public:
   CFilterManager(): m_trend(NULL),m_news(NULL),m_spread(NULL),m_sched(NULL),m_stoch(NULL) {}

   void Init(CTrendFilter &tr, CNewsFilter &nw, CSpreadFilter &sp,
             CScheduleFilter &sc, CStochasticFilter &st)
   { m_trend=&tr; m_news=&nw; m_spread=&sp; m_sched=&sc; m_stoch=&st;
     Logger.Info("FilterManager: All filters registered"); }

   void Update() { if(m_news!=NULL) m_news.Update(); }

   bool ApplyFilters(ENUM_ORDER_TYPE type, bool isGrid=false)
   {
      m_reason="";
      #define CHK(f, call) if(f!=NULL && !f.call){ m_reason=f.GetRejectionReason(); return false; }
      CHK(m_sched,  IsTradeAllowed(type))
      CHK(m_news,   IsTradeAllowed(type))
      CHK(m_spread, IsTradeAllowed(type))
      CHK(m_trend,  IsTradeAllowed(type))
      if(m_stoch!=NULL && !m_stoch.IsTradeAllowed(type, isGrid))
      { m_reason=m_stoch.GetRejectionReason(); return false; }
      #undef CHK
      return true;
   }

   string GetLastRejectionReason() const { return m_reason; }
   bool   IsNewsSuspended()        const { return m_news!=NULL && m_news.IsSuspended(); }
};

#endif
