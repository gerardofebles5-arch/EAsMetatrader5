//+------------------------------------------------------------------+
//|  TrendFilter.mqh  -  Money Machine 7                             |
//+------------------------------------------------------------------+
#ifndef __MM7_TRENDFILTER__
#define __MM7_TRENDFILTER__

#include "..\Utils\Logger.mqh"
#include "..\Market\IndicatorCache.mqh"

class CTrendFilter
{
private:
   bool             m_en;
   string           m_sym;
   CIndicatorCache* m_cache;
   string           m_reason;

public:
   CTrendFilter(): m_en(false), m_cache(NULL) {}

   void Init(bool en, string sym, CIndicatorCache &cache)
   { m_en=en; m_sym=sym; m_cache=&cache;
     Logger.Info("TrendFilter: "+(en?"ENABLED":"DISABLED")); }

   bool IsTradeAllowed(ENUM_ORDER_TYPE type)
   {
      if(!m_en) return true;
      double ma=(m_cache!=NULL)?m_cache.GetMA(0):0;
      if(ma<=0) return true;
      double cl=iClose(m_sym,PERIOD_CURRENT,1);
      if(type==ORDER_TYPE_BUY && cl<ma)
      { m_reason="TrendFilter: BUY blocked – price below MA("+DoubleToString(ma,_Digits)+")"; return false; }
      if(type==ORDER_TYPE_SELL && cl>ma)
      { m_reason="TrendFilter: SELL blocked – price above MA("+DoubleToString(ma,_Digits)+")"; return false; }
      return true;
   }
   string GetRejectionReason() const { return m_reason; }
};

#endif
