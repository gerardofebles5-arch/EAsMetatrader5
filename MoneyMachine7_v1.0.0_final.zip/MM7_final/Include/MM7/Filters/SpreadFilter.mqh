//+------------------------------------------------------------------+
//|  SpreadFilter.mqh  -  Money Machine 7                            |
//+------------------------------------------------------------------+
#ifndef __MM7_SPREADFILTER__
#define __MM7_SPREADFILTER__

#include "..\Utils\Logger.mqh"

class CSpreadFilter
{
private:
   string m_sym;
   int    m_maxSpread;
   string m_reason;

public:
   CSpreadFilter(): m_maxSpread(50) {}

   void Init(string sym, int maxSpread)
   { m_sym=sym; m_maxSpread=maxSpread;
     Logger.Info("SpreadFilter: max="+IntegerToString(maxSpread)+"pts"); }

   bool IsTradeAllowed(ENUM_ORDER_TYPE type)
   {
      int sp=(int)SymbolInfoInteger(m_sym,SYMBOL_SPREAD);
      if(sp > m_maxSpread)
      { m_reason="SpreadFilter: "+IntegerToString(sp)+"pts > max "+IntegerToString(m_maxSpread)+"pts";
        Logger.Warning(m_reason); return false; }
      return true;
   }

   string GetRejectionReason() const { return m_reason; }
   int    GetCurrentSpread()   const { return (int)SymbolInfoInteger(m_sym,SYMBOL_SPREAD); }
};

#endif
