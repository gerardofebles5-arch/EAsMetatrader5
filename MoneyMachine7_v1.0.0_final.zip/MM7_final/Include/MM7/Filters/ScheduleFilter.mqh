//+------------------------------------------------------------------+
//|  ScheduleFilter.mqh  -  Money Machine 7                          |
//+------------------------------------------------------------------+
#ifndef __MM7_SCHEDULEFILTER__
#define __MM7_SCHEDULEFILTER__

#include "..\Utils\Logger.mqh"

struct DaySchedule { bool active; int startH; int endH; };

class CScheduleFilter
{
private:
   DaySchedule m_days[7]; // 0=Sun … 6=Sat
   string      m_reason;

public:
   CScheduleFilter() { for(int i=0;i<7;i++){ m_days[i].active=false; m_days[i].startH=0; m_days[i].endH=23; } }

   // Mon‑Fri with hours; Sat/Sun bool only
   void Init(bool monA,int monS,int monE,
             bool tueA,int tueS,int tueE,
             bool wedA,int wedS,int wedE,
             bool thuA,int thuS,int thuE,
             bool friA,int friS,int friE,
             bool satA, bool sunA)
   {
      m_days[0].active=sunA; m_days[0].startH=0;    m_days[0].endH=23;
      m_days[1].active=monA; m_days[1].startH=monS; m_days[1].endH=monE;
      m_days[2].active=tueA; m_days[2].startH=tueS; m_days[2].endH=tueE;
      m_days[3].active=wedA; m_days[3].startH=wedS; m_days[3].endH=wedE;
      m_days[4].active=thuA; m_days[4].startH=thuS; m_days[4].endH=thuE;
      m_days[5].active=friA; m_days[5].startH=friS; m_days[5].endH=friE;
      m_days[6].active=satA; m_days[6].startH=0;    m_days[6].endH=23;
      Logger.Info("ScheduleFilter: Configured");
   }

   bool IsTradeAllowed(ENUM_ORDER_TYPE type)
   {
      MqlDateTime dt; TimeToStruct(TimeCurrent(),dt);
      DaySchedule &d=m_days[dt.day_of_week];
      if(!d.active)
      { m_reason="ScheduleFilter: day "+IntegerToString(dt.day_of_week)+" inactive"; return false; }
      if(dt.hour<d.startH || dt.hour>=d.endH)
      { m_reason="ScheduleFilter: outside "+IntegerToString(d.startH)+":00-"+IntegerToString(d.endH)+":00"; return false; }
      return true;
   }
   string GetRejectionReason() const { return m_reason; }
};

#endif
