//+------------------------------------------------------------------+
//|  BasketManager.mqh  -  Money Machine 7                           |
//+------------------------------------------------------------------+
#ifndef __MM7_BASKET__
#define __MM7_BASKET__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "PositionTracker.mqh"
#include "OrderExecutor.mqh"

class CBasketManager
{
private:
   double            m_profitTarget;
   double            m_lossLimit;
   CPositionTracker* m_tracker;
   COrderExecutor*   m_exec;

   int CloseAll(string reason)
   {
      int closed=0;
      for(int i=m_tracker.GetTotalCount()-1;i>=0;i--)
      {
         PositionInfo pos;
         if(m_tracker.GetByIndex(i,pos) && m_exec.ClosePosition(pos.ticket)) closed++;
      }
      Logger.Info("Basket: Closed "+IntegerToString(closed)+" positions | "+reason);
      return closed;
   }

public:
   CBasketManager(): m_profitTarget(100), m_lossLimit(50), m_tracker(NULL), m_exec(NULL) {}

   void Init(double profitUSD, double lossUSD, CPositionTracker &tr, COrderExecutor &ex)
   {
      m_profitTarget=profitUSD; m_lossLimit=lossUSD;
      m_tracker=&tr; m_exec=&ex;
      Logger.Info("Basket: ProfitTarget="+DoubleToString(profitUSD,2)
                  +" LossLimit="+DoubleToString(lossUSD,2));
   }

   void ManageBasket()
   {
      if(m_tracker.GetTotalCount()==0) return;
      double pl=m_tracker.GetTotalProfit();

      if(m_profitTarget>0 && pl>=m_profitTarget)
      { Logger.Info("Basket: Profit target reached PL="+DoubleToString(pl,2));
        CloseAll("Profit target "+DoubleToString(m_profitTarget,2)); return; }

      if(m_lossLimit>0 && pl<=-m_lossLimit)
      { Logger.Warning("Basket: Loss limit reached PL="+DoubleToString(pl,2));
        CloseAll("Loss limit "+DoubleToString(m_lossLimit,2)); }
   }
};

#endif
