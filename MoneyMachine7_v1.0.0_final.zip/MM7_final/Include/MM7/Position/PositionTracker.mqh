//+------------------------------------------------------------------+
//|  PositionTracker.mqh  -  Money Machine 7                         |
//+------------------------------------------------------------------+
#ifndef __MM7_POSITIONTRACKER__
#define __MM7_POSITIONTRACKER__

#include "..\Core\DataStructures.mqh"
#include "..\Utils\Logger.mqh"

class CPositionTracker
{
private:
   long         m_magic;
   bool         m_ctrlUser;
   PositionInfo m_pos[];
   int          m_buys, m_sells;

   int FindIdx(ulong ticket)
   {
      for(int i=0;i<ArraySize(m_pos);i++) if(m_pos[i].ticket==ticket) return i;
      return -1;
   }

public:
   CPositionTracker(): m_magic(700000), m_ctrlUser(false), m_buys(0), m_sells(0) {}

   void Init(long magic, bool ctrlUser)
   {
      m_magic=magic; m_ctrlUser=ctrlUser;
      ArrayResize(m_pos,0);
      Logger.Info("PositionTracker: Init magic="+IntegerToString((int)magic)
                  +" controlUser="+(ctrlUser?"YES":"NO"));
   }

   void UpdatePositions()
   {
      int total=PositionsTotal();
      PositionInfo upd[];
      ArrayResize(upd,0);
      m_buys=0; m_sells=0;

      for(int i=0;i<total;i++)
      {
         ulong ticket=PositionGetTicket(i);
         if(!PositionSelectByTicket(ticket)) continue;
         long mg=(long)PositionGetInteger(POSITION_MAGIC);
         bool ours=(mg==m_magic);
         bool manual=(m_ctrlUser && mg==0);
         if(!ours && !manual) continue;

         int n=ArraySize(upd);
         ArrayResize(upd,n+1);
         upd[n].ticket       = ticket;
         upd[n].type         = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         upd[n].openPrice    = PositionGetDouble(POSITION_PRICE_OPEN);
         upd[n].currentPrice = PositionGetDouble(POSITION_PRICE_CURRENT);
         upd[n].lots         = PositionGetDouble(POSITION_VOLUME);
         upd[n].profit       = PositionGetDouble(POSITION_PROFIT);
         upd[n].openTime     = (datetime)PositionGetInteger(POSITION_TIME);
         upd[n].strategy     = PositionGetString(POSITION_COMMENT);

         int ex=FindIdx(ticket);
         if(ex>=0)
         {
            upd[n].virtualTP      = m_pos[ex].virtualTP;
            upd[n].virtualSL      = m_pos[ex].virtualSL;
            upd[n].trailingActive = m_pos[ex].trailingActive;
            upd[n].breakevenSet   = m_pos[ex].breakevenSet;
         }
         else
         {
            upd[n].virtualTP      = PositionGetDouble(POSITION_TP);
            upd[n].virtualSL      = PositionGetDouble(POSITION_SL);
            upd[n].trailingActive = false;
            upd[n].breakevenSet   = false;
         }
         if(upd[n].type==POSITION_TYPE_BUY) m_buys++; else m_sells++;
      }
      ArrayCopy(m_pos, upd);
   }

   bool GetByIndex(int idx, PositionInfo &out)
   {
      if(idx<0||idx>=ArraySize(m_pos)) return false;
      out=m_pos[idx]; return true;
   }
   bool GetByTicket(ulong ticket, PositionInfo &out)
   {
      int i=FindIdx(ticket); if(i<0) return false;
      out=m_pos[i]; return true;
   }

   bool SetVirtualLevels(ulong ticket, double vTP, double vSL)
   {
      int i=FindIdx(ticket); if(i<0) return false;
      m_pos[i].virtualTP=vTP; m_pos[i].virtualSL=vSL; return true;
   }
   bool SetTrailingActive(ulong ticket, bool v)
   { int i=FindIdx(ticket); if(i<0) return false; m_pos[i].trailingActive=v; return true; }
   bool SetBreakevenSet(ulong ticket, bool v)
   { int i=FindIdx(ticket); if(i<0) return false; m_pos[i].breakevenSet=v; return true; }

   int GetAllPositions(PositionInfo &dest[])
   { ArrayCopy(dest,m_pos); return ArraySize(m_pos); }

   int    GetBuyCount()   const { return m_buys; }
   int    GetSellCount()  const { return m_sells; }
   int    GetTotalCount() const { return ArraySize(m_pos); }

   double GetTotalProfit()
   {
      double t=0;
      for(int i=0;i<ArraySize(m_pos);i++) t+=m_pos[i].profit;
      return t;
   }
};

#endif
