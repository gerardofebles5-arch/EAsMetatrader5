//+------------------------------------------------------------------+
//|  OrderExecutor.mqh  -  Money Machine 7                           |
//+------------------------------------------------------------------+
#ifndef __MM7_ORDEREXECUTOR__
#define __MM7_ORDEREXECUTOR__

#include <Trade\Trade.mqh>
#include "..\Utils\Logger.mqh"

class COrderExecutor
{
private:
   CTrade  m_trade;
   string  m_sym;
   long    m_magic;
   string  m_comment;
   int     m_slip;
   int     m_digits;

   double NP(double p){ return NormalizeDouble(p, m_digits); }
   double NormLot(double lot)
   {
      double step=SymbolInfoDouble(m_sym,SYMBOL_VOLUME_STEP);
      double mn  =SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MIN);
      double mx  =SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MAX);
      if(step>0) lot=MathFloor(lot/step)*step;
      return NormalizeDouble(MathMax(mn, MathMin(mx, lot)), 2);
   }

public:
   COrderExecutor(): m_magic(700000), m_comment("MM7"), m_slip(10), m_digits(5) {}

   void Init(string sym, long magic, string comment, int slip)
   {
      m_sym=sym; m_magic=magic; m_comment=comment; m_slip=slip;
      m_digits=(int)SymbolInfoInteger(sym, SYMBOL_DIGITS);

      m_trade.SetExpertMagicNumber(magic);
      m_trade.SetDeviationInPoints(slip);

      // Select best available filling mode
      int fillMode=(int)SymbolInfoInteger(sym, SYMBOL_FILLING_MODE);
      if((fillMode & SYMBOL_FILLING_FOK)!=0)
         m_trade.SetTypeFilling(ORDER_FILLING_FOK);
      else if((fillMode & SYMBOL_FILLING_IOC)!=0)
         m_trade.SetTypeFilling(ORDER_FILLING_IOC);
      else
         m_trade.SetTypeFilling(ORDER_FILLING_RETURN);

      Logger.Info("OrderExecutor: Init sym="+sym+" magic="+IntegerToString((int)magic)
                  +" slip="+IntegerToString(slip));
   }

   ulong OpenPosition(ENUM_ORDER_TYPE type, double lots,
                      double tp, double sl, string tag="")
   {
      lots=NormLot(lots);
      if(lots<=0){ Logger.Error("OrderExecutor: Invalid lots after normalise"); return 0; }

      string cmt = m_comment + (tag!=""?":"+tag:"");
      double price = (type==ORDER_TYPE_BUY)
                     ? SymbolInfoDouble(m_sym,SYMBOL_ASK)
                     : SymbolInfoDouble(m_sym,SYMBOL_BID);
      if(tp>0) tp=NP(tp);
      if(sl>0) sl=NP(sl);

      bool ok = (type==ORDER_TYPE_BUY)
                ? m_trade.Buy (lots, m_sym, price, sl, tp, cmt)
                : m_trade.Sell(lots, m_sym, price, sl, tp, cmt);

      if(!ok)
      { Logger.TradeError("OrderExecutor::Open("+EnumToString(type)+")", (int)m_trade.ResultRetcode()); return 0; }

      ulong ticket=m_trade.ResultOrder();
      Logger.Info("OrderExecutor: Opened "+EnumToString(type)
                  +" #"+IntegerToString((int)ticket)
                  +" lot="+DoubleToString(lots,2)
                  +" price="+DoubleToString(price,m_digits)
                  +(sl>0?" SL="+DoubleToString(sl,m_digits):"")
                  +(tp>0?" TP="+DoubleToString(tp,m_digits):"")
                  +" ["+tag+"]");
      return ticket;
   }

   bool ClosePosition(ulong ticket)
   {
      if(!PositionSelectByTicket(ticket))
      { Logger.Warning("OrderExecutor: ClosePosition ticket #"+IntegerToString((int)ticket)+" not found"); return false; }
      bool ok=m_trade.PositionClose(ticket, m_slip);
      if(!ok) Logger.TradeError("OrderExecutor::Close #"+IntegerToString((int)ticket), (int)m_trade.ResultRetcode());
      else    Logger.Info("OrderExecutor: Closed #"+IntegerToString((int)ticket));
      return ok;
   }

   bool ModifyPosition(ulong ticket, double newTP, double newSL)
   {
      if(!PositionSelectByTicket(ticket))
      { Logger.Warning("OrderExecutor: Modify ticket #"+IntegerToString((int)ticket)+" not found"); return false; }
      if(newTP>0) newTP=NP(newTP);
      if(newSL>0) newSL=NP(newSL);
      bool ok=m_trade.PositionModify(ticket, newSL, newTP);
      if(!ok) Logger.TradeError("OrderExecutor::Modify #"+IntegerToString((int)ticket), (int)m_trade.ResultRetcode());
      return ok;
   }
};

#endif
