//+------------------------------------------------------------------+
//|  StealthModeManager.mqh  -  Money Machine 7                      |
//+------------------------------------------------------------------+
#ifndef __MM7_STEALTH__
#define __MM7_STEALTH__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "PositionTracker.mqh"
#include "OrderExecutor.mqh"

class CStealthModeManager
{
private:
   bool              m_en;
   string            m_sym;
   CPositionTracker* m_tracker;
   COrderExecutor*   m_exec;

public:
   CStealthModeManager(): m_en(false), m_tracker(NULL), m_exec(NULL) {}

   void Init(bool en, string sym, CPositionTracker &tr, COrderExecutor &ex)
   { m_en=en; m_sym=sym; m_tracker=&tr; m_exec=&ex;
     Logger.Info("StealthMode: "+(en?"ENABLED":"DISABLED")); }

   void ManageStealthMode()
   {
      if(!m_en) return;
      int total=m_tracker.GetTotalCount();
      for(int i=0;i<total;i++)
      {
         PositionInfo pos;
         if(!m_tracker.GetByIndex(i,pos)) continue;
         if(pos.virtualTP<=0 && pos.virtualSL<=0) continue;

         double price=(pos.type==POSITION_TYPE_BUY)
                      ? SymbolInfoDouble(m_sym,SYMBOL_ASK)
                      : SymbolInfoDouble(m_sym,SYMBOL_BID);

         // Virtual TP
         if(pos.virtualTP>0)
         {
            bool hit=(pos.type==POSITION_TYPE_BUY && price>=pos.virtualTP)
                   ||(pos.type==POSITION_TYPE_SELL && price<=pos.virtualTP);
            if(hit)
            { Logger.Info("Stealth: vTP hit #"+IntegerToString((int)pos.ticket)+" price="+DoubleToString(price,_Digits));
              m_exec.ClosePosition(pos.ticket); continue; }
         }
         // Virtual SL
         if(pos.virtualSL>0)
         {
            bool hit=(pos.type==POSITION_TYPE_BUY && price<=pos.virtualSL)
                   ||(pos.type==POSITION_TYPE_SELL && price>=pos.virtualSL);
            if(hit)
            { Logger.Info("Stealth: vSL hit #"+IntegerToString((int)pos.ticket)+" price="+DoubleToString(price,_Digits));
              m_exec.ClosePosition(pos.ticket); }
         }
      }
   }

   bool IsEnabled() const { return m_en; }
};

#endif
