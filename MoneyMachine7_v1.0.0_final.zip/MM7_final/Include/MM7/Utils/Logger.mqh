//+------------------------------------------------------------------+
//|  Logger.mqh  -  Money Machine 7                                  |
//+------------------------------------------------------------------+
#ifndef __MM7_LOGGER__
#define __MM7_LOGGER__

enum ENUM_LOG_LEVEL { LOG_DEBUG=0, LOG_INFO=1, LOG_WARNING=2, LOG_ERROR=3 };

class CLogger
{
private:
   ENUM_LOG_LEVEL m_level;
   string         m_ctx;

   string LvStr(ENUM_LOG_LEVEL lv)
   {
      if(lv==LOG_DEBUG)   return "[DEBUG]";
      if(lv==LOG_INFO)    return "[INFO ]";
      if(lv==LOG_WARNING) return "[WARN ]";
      return "[ERROR]";
   }

   void Write(ENUM_LOG_LEVEL lv, const string msg)
   {
      if(lv < m_level) return;
      MqlDateTime d; TimeToStruct(TimeCurrent(), d);
      string ts = StringFormat("%04d.%02d.%02d %02d:%02d:%02d",
                                d.year,d.mon,d.day,d.hour,d.min,d.sec);
      string pfx = (m_ctx!="") ? "["+m_ctx+"] " : "";
      Print(ts+" "+LvStr(lv)+" "+pfx+msg);
   }

public:
   CLogger(): m_level(LOG_INFO), m_ctx("") {}

   void Init(ENUM_LOG_LEVEL lv=LOG_INFO, string ctx="") { m_level=lv; m_ctx=ctx; }
   void SetLevel(ENUM_LOG_LEVEL lv) { m_level=lv; }

   void Debug  (const string m) { Write(LOG_DEBUG,  m); }
   void Info   (const string m) { Write(LOG_INFO,   m); }
   void Warning(const string m) { Write(LOG_WARNING,m); }
   void Error  (const string m) { Write(LOG_ERROR,  m); }

   void TradeError(const string op, int code)
   {
      Write(LOG_ERROR, op+" FAILED Code="+IntegerToString(code)+" ("+TDesc(code)+")");
   }

   string TDesc(int c)
   {
      switch(c)
      {
         case TRADE_RETCODE_REQUOTE:            return "Requote";
         case TRADE_RETCODE_REJECT:             return "Rejected";
         case TRADE_RETCODE_CANCEL:             return "Canceled";
         case TRADE_RETCODE_PLACED:             return "Placed";
         case TRADE_RETCODE_DONE:               return "Done";
         case TRADE_RETCODE_DONE_PARTIAL:       return "Done partial";
         case TRADE_RETCODE_ERROR:              return "Error";
         case TRADE_RETCODE_TIMEOUT:            return "Timeout";
         case TRADE_RETCODE_INVALID:            return "Invalid request";
         case TRADE_RETCODE_INVALID_VOLUME:     return "Invalid volume";
         case TRADE_RETCODE_INVALID_PRICE:      return "Invalid price";
         case TRADE_RETCODE_INVALID_STOPS:      return "Invalid stops";
         case TRADE_RETCODE_TRADE_DISABLED:     return "Trade disabled";
         case TRADE_RETCODE_MARKET_CLOSED:      return "Market closed";
         case TRADE_RETCODE_NO_MONEY:           return "No money";
         case TRADE_RETCODE_PRICE_CHANGED:      return "Price changed";
         case TRADE_RETCODE_PRICE_OFF:          return "No quotes";
         case TRADE_RETCODE_INVALID_EXPIRATION: return "Invalid expiration";
         case TRADE_RETCODE_TOO_MANY_REQUESTS:  return "Too many requests";
         case TRADE_RETCODE_NO_CHANGES:         return "No changes";
         case TRADE_RETCODE_LOCKED:             return "Locked";
         case TRADE_RETCODE_FROZEN:             return "Frozen";
         case TRADE_RETCODE_INVALID_FILL:       return "Invalid fill";
         case TRADE_RETCODE_CONNECTION:         return "No connection";
         case TRADE_RETCODE_ONLY_REAL:          return "Real only";
         case TRADE_RETCODE_LIMIT_ORDERS:       return "Orders limit";
         case TRADE_RETCODE_LIMIT_VOLUME:       return "Volume limit";
         case TRADE_RETCODE_INVALID_ORDER:      return "Invalid order";
         case TRADE_RETCODE_POSITION_CLOSED:    return "Position closed";
         default: return "Unknown("+IntegerToString(c)+")";
      }
   }
};

CLogger Logger;
#endif
