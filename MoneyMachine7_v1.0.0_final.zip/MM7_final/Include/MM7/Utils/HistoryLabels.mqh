//+------------------------------------------------------------------+
//|  HistoryLabels.mqh  -  Money Machine 7                           |
//+------------------------------------------------------------------+
#ifndef __MM7_HISTORYLABELS__
#define __MM7_HISTORYLABELS__

#include "..\Utils\Logger.mqh"

class CHistoryLabels
{
private:
   bool   m_en;
   int    m_limit;
   long   m_magic;
   string m_pfx;

   void CreateLabel(datetime closeTime, double closePrice, double profit, ulong ticket)
   {
      string nm=m_pfx+IntegerToString((int)ticket);
      if(ObjectFind(0,nm)>=0) return;
      color c=(profit>=0)?(color)clrLime:(color)clrRed;
      string txt=(profit>=0?"+":"")+DoubleToString(profit,2);
      ObjectCreate(0,nm,OBJ_TEXT,0,closeTime,closePrice);
      ObjectSetString (0,nm,OBJPROP_TEXT,     txt);
      ObjectSetInteger(0,nm,OBJPROP_COLOR,    c);
      ObjectSetInteger(0,nm,OBJPROP_FONTSIZE, 8);
      ObjectSetString (0,nm,OBJPROP_FONT,     "Arial Bold");
      ObjectSetInteger(0,nm,OBJPROP_ANCHOR,   ANCHOR_LOWER);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_BACK,     false);
   }

public:
   CHistoryLabels(): m_en(false), m_limit(50), m_magic(700000), m_pfx("MM7_HL_") {}

   void Init(bool en, int limit, long magic)
   { m_en=en; m_limit=limit; m_magic=magic;
     Logger.Info("HistoryLabels: "+(en?"ENABLED":"DISABLED")+" limit="+IntegerToString(limit)); }

   void DrawHistoryLabels()
   {
      if(!m_en) return;
      if(!HistorySelect(D'2000.01.01', TimeCurrent())) return;
      int total=HistoryDealsTotal(); int drawn=0;
      for(int i=total-1;i>=0 && drawn<m_limit;i--)
      {
         ulong tk=HistoryDealGetTicket(i);
         if(tk==0) continue;
         if(HistoryDealGetInteger(tk,DEAL_ENTRY)!=DEAL_ENTRY_OUT) continue;
         if(HistoryDealGetInteger(tk,DEAL_MAGIC)!=m_magic) continue;
         double pl=HistoryDealGetDouble(tk,DEAL_PROFIT)
                  +HistoryDealGetDouble(tk,DEAL_COMMISSION)
                  +HistoryDealGetDouble(tk,DEAL_SWAP);
         CreateLabel((datetime)HistoryDealGetInteger(tk,DEAL_TIME),
                     HistoryDealGetDouble(tk,DEAL_PRICE), pl, tk);
         drawn++;
      }
   }

   void RemoveAllLabels()
   {
      for(int i=ObjectsTotal(0)-1;i>=0;i--)
      { string nm=ObjectName(0,i); if(StringFind(nm,m_pfx)==0) ObjectDelete(0,nm); }
   }
};

#endif
