//+------------------------------------------------------------------+
//|  TrailingStop.mqh  -  Money Machine 7                            |
//+------------------------------------------------------------------+
#ifndef __MM7_TRAILING__
#define __MM7_TRAILING__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "..\Market\IndicatorCache.mqh"
#include "PositionTracker.mqh"
#include "OrderExecutor.mqh"

class CTrailingStop
{
private:
   bool              m_en, m_stealth;
   string            m_sym;
   double            m_startMult, m_distMult;
   int               m_digits;
   CIndicatorCache*  m_cache;
   CPositionTracker* m_tracker;
   COrderExecutor*   m_exec;

   double NP(double p){ return NormalizeDouble(p,m_digits); }

public:
   CTrailingStop(): m_en(false), m_stealth(true),
                    m_startMult(1.5), m_distMult(1), m_digits(5),
                    m_cache(NULL), m_tracker(NULL), m_exec(NULL) {}

   void Init(bool en, bool stealth, string sym,
             double startMult, double distMult,
             CIndicatorCache &cache, CPositionTracker &tracker, COrderExecutor &exec)
   {
      m_en=en; m_stealth=stealth; m_sym=sym;
      m_startMult=startMult; m_distMult=distMult;
      m_digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
      m_cache=&cache; m_tracker=&tracker; m_exec=&exec;
      Logger.Info("TrailingStop: "+(en?"ENABLED":"DISABLED")
                  +" startMult="+DoubleToString(startMult,2)
                  +" distMult="+DoubleToString(distMult,2));
   }

   void UpdateAll()
   {
      if(!m_en) return;
      double atr=(m_cache!=NULL)?m_cache.GetATR(0):0;
      if(atr<=0) return;
      int total=m_tracker.GetTotalCount();
      for(int i=0;i<total;i++)
      {
         PositionInfo pos;
         if(m_tracker.GetByIndex(i,pos)) UpdateOne(pos,atr);
      }
   }

private:
   void UpdateOne(PositionInfo &pos, double atr)
   {
      bool buy=(pos.type==POSITION_TYPE_BUY);
      double curPrice=buy?SymbolInfoDouble(m_sym,SYMBOL_BID):SymbolInfoDouble(m_sym,SYMBOL_ASK);
      double profit=buy?(curPrice-pos.openPrice):(pos.openPrice-curPrice);

      if(profit < m_startMult*atr) return;

      double curSL=m_stealth?pos.virtualSL:PositionGetDouble(POSITION_SL);
      double newSL=NP(buy ? curPrice-m_distMult*atr : curPrice+m_distMult*atr);
      bool better=(curSL<=0)||(buy?newSL>curSL:newSL<curSL);
      if(!better) return;

      if(m_stealth)
         m_tracker.SetVirtualLevels(pos.ticket, pos.virtualTP, newSL);
      else
      {
         double brokerTP=PositionGetDouble(POSITION_TP);
         m_exec.ModifyPosition(pos.ticket, brokerTP, newSL);
      }
      m_tracker.SetTrailingActive(pos.ticket, true);
      Logger.Debug("Trailing: #"+IntegerToString((int)pos.ticket)+" newSL="+DoubleToString(newSL,_Digits));
   }
};

#endif
