//+------------------------------------------------------------------+
//|  PositionSizer.mqh  -  Money Machine 7                           |
//+------------------------------------------------------------------+
#ifndef __MM7_POSITIONSIZER__
#define __MM7_POSITIONSIZER__

#include "..\Utils\Logger.mqh"

class CPositionSizer
{
private:
   string m_sym;
   bool   m_dynamic;
   double m_baseLot;
   double m_marginPerLot;
   double m_maxLot;
   double m_kmartin;

   double NormLot(double lot)
   {
      double step=SymbolInfoDouble(m_sym,SYMBOL_VOLUME_STEP);
      double mn  =SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MIN);
      double mx  =SymbolInfoDouble(m_sym,SYMBOL_VOLUME_MAX);
      if(step>0) lot=MathFloor(lot/step)*step;
      return NormalizeDouble(MathMax(mn, MathMin(MathMin(m_maxLot,mx), lot)), 2);
   }

public:
   CPositionSizer(): m_dynamic(true), m_baseLot(0.01),
                     m_marginPerLot(1000), m_maxLot(10), m_kmartin(1) {}

   void Init(string sym, bool dynamic, double base,
             double marginPerLot, double maxLot, double kmartin)
   {
      m_sym=sym; m_dynamic=dynamic; m_baseLot=base;
      m_marginPerLot=marginPerLot; m_maxLot=maxLot; m_kmartin=kmartin;
      Logger.Info("PositionSizer: dynamic="+(dynamic?"YES":"NO")
                  +" base="+DoubleToString(base,2)+" kmartin="+DoubleToString(kmartin,2));
   }

   double CalculateLotSize(int gridN=0)
   {
      double lot=m_baseLot;
      if(m_dynamic)
      {
         double fm=AccountInfoDouble(ACCOUNT_FREEMARGIN);
         double mpl=(m_marginPerLot>0)?m_marginPerLot:1000;
         lot=(fm/mpl)*m_baseLot;
      }
      if(gridN>0 && m_kmartin!=1.0)
         lot*=MathPow(m_kmartin, gridN);

      lot=NormLot(lot);
      Logger.Debug("PositionSizer: lot="+DoubleToString(lot,2)+(gridN>0?" gridN="+IntegerToString(gridN):""));
      return lot;
   }
};

#endif
