//+------------------------------------------------------------------+
//|  Breakeven.mqh  -  Money Machine 7                               |
//+------------------------------------------------------------------+
#ifndef __MM7_BREAKEVEN__
#define __MM7_BREAKEVEN__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "..\Market\IndicatorCache.mqh"
#include "PositionTracker.mqh"
#include "OrderExecutor.mqh"

class CBreakeven
{
private:
   bool              m_en, m_stealth;
   string            m_sym;
   double            m_trigMult, m_profitPts;
   int               m_digits;
   CIndicatorCache*  m_cache;
   CPositionTracker* m_tracker;
   COrderExecutor*   m_exec;

   double NP(double p){ return NormalizeDouble(p,m_digits); }

public:
   CBreakeven(): m_en(false), m_stealth(true),
                 m_trigMult(1), m_profitPts(5), m_digits(5),
                 m_cache(NULL), m_tracker(NULL), m_exec(NULL) {}

   void Init(bool en, bool stealth, string sym,
             double trigMult, double profitPts,
             CIndicatorCache &cache, CPositionTracker &tracker, COrderExecutor &exec)
   {
      m_en=en; m_stealth=stealth; m_sym=sym;
      m_trigMult=trigMult; m_profitPts=profitPts;
      m_digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
      m_cache=&cache; m_tracker=&tracker; m_exec=&exec;
      Logger.Info("Breakeven: "+(en?"ENABLED":"DISABLED")
                  +" trigMult="+DoubleToString(trigMult,2)
                  +" pts="+DoubleToString(profitPts,1));
   }

   void UpdateAll()
   {
      if(!m_en) return;
      double atr=(m_cache!=NULL)?m_cache.GetATR(0):0;
      if(atr<=0) return;
      int total=m_tracker.GetTotalCount();
      for(int i=0;i<total;i++)
      {
         PositionInfo pos;
         if(m_tracker.GetByIndex(i,pos)) UpdateOne(pos,atr);
      }
   }

private:
   void UpdateOne(PositionInfo &pos, double atr)
   {
      if(pos.breakevenSet || pos.trailingActive) return;
      bool buy=(pos.type==POSITION_TYPE_BUY);
      double curPrice=buy?SymbolInfoDouble(m_sym,SYMBOL_BID):SymbolInfoDouble(m_sym,SYMBOL_ASK);
      double profit=buy?(curPrice-pos.openPrice):(pos.openPrice-curPrice);
      if(profit < m_trigMult*atr) return;

      double pt=SymbolInfoDouble(m_sym,SYMBOL_POINT);
      double newSL=NP(buy ? pos.openPrice+m_profitPts*pt : pos.openPrice-m_profitPts*pt);

      if(m_stealth)
         m_tracker.SetVirtualLevels(pos.ticket, pos.virtualTP, newSL);
      else
      {
         double brokerTP=PositionGetDouble(POSITION_TP);
         m_exec.ModifyPosition(pos.ticket, brokerTP, newSL);
      }
      m_tracker.SetBreakevenSet(pos.ticket, true);
      Logger.Info("Breakeven: #"+IntegerToString((int)pos.ticket)+" SL moved to "+DoubleToString(newSL,m_digits));
   }
};

#endif
