//+------------------------------------------------------------------+
//|  RiskLimitsMonitor.mqh  -  Money Machine 7                       |
//+------------------------------------------------------------------+
#ifndef __MM7_RISKMONITOR__
#define __MM7_RISKMONITOR__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"

class CRiskLimitsMonitor
{
private:
   double       m_dailyLossUSD;
   double       m_dailyLossPct;
   double       m_equityDDPct;
   double       m_maxDDPct;
   double       m_dailyProfitUSD;
   int          m_stopLosses;
   RiskMetrics* m_m;

   bool SameDay(datetime a, datetime b)
   {
      MqlDateTime da,db; TimeToStruct(a,da); TimeToStruct(b,db);
      return da.year==db.year && da.mon==db.mon && da.day==db.day;
   }

public:
   CRiskLimitsMonitor(): m_dailyLossUSD(100),m_dailyLossPct(5),
                         m_equityDDPct(10),m_maxDDPct(15),
                         m_dailyProfitUSD(200),m_stopLosses(5),m_m(NULL) {}

   void Init(double dailyLossUSD, double dailyLossPct,
             double equityDDPct, double maxDDPct,
             double dailyProfitUSD, int stopLosses,
             RiskMetrics &metrics)
   {
      m_dailyLossUSD=dailyLossUSD; m_dailyLossPct=dailyLossPct;
      m_equityDDPct=equityDDPct;   m_maxDDPct=maxDDPct;
      m_dailyProfitUSD=dailyProfitUSD; m_stopLosses=stopLosses;
      m_m=&metrics;
      Logger.Info("RiskMonitor: dailyLoss="+DoubleToString(dailyLossUSD,0)+"USD"
                  +" maxDD="+DoubleToString(maxDDPct,1)+"%"
                  +" stopAfter="+IntegerToString(stopLosses));
   }

   // Returns false = block new entries
   bool CheckRiskLimits()
   {
      if(m_m==NULL) return true;
      datetime now=TimeCurrent();

      // Daily reset
      if(!SameDay(now, m_m.lastResetTime))
      {
         m_m.dailyProfit=0; m_m.dailyLoss=0;
         m_m.consecutiveLosses=0; m_m.tradingAllowed=true;
         m_m.lastResetTime=now;
         Logger.Info("RiskMonitor: Daily counters reset");
      }

      // Equity peak tracking
      double eq=AccountInfoDouble(ACCOUNT_EQUITY);
      if(eq > m_m.equityPeak) m_m.equityPeak=eq;
      double ddPct=(m_m.equityPeak>0)?((m_m.equityPeak-eq)/m_m.equityPeak)*100:0;
      m_m.currentDrawdown=ddPct;
      if(ddPct>m_m.maxDrawdown) m_m.maxDrawdown=ddPct;

      // Check each limit
      if(m_m.dailyLoss >= m_dailyLossUSD)
      { SetHalted("Daily loss USD limit "+DoubleToString(m_dailyLossUSD,2)); return false; }

      double bal=AccountInfoDouble(ACCOUNT_BALANCE);
      if(bal>0 && (m_m.dailyLoss/bal)*100 >= m_dailyLossPct)
      { SetHalted("Daily loss % limit "+DoubleToString(m_dailyLossPct,1)+"%"); return false; }

      if(ddPct >= m_equityDDPct)
      { SetHalted("Equity drawdown limit "+DoubleToString(m_equityDDPct,1)+"%"); return false; }

      if(ddPct >= m_maxDDPct)
      { SetHalted("Max drawdown limit "+DoubleToString(m_maxDDPct,1)+"%"); return false; }

      if(m_m.consecutiveLosses >= m_stopLosses)
      { SetHalted("Consecutive losses "+IntegerToString(m_stopLosses)); return false; }

      if(m_dailyProfitUSD>0 && m_m.dailyProfit >= m_dailyProfitUSD)
      {
         Logger.Debug("RiskMonitor: Daily profit target reached - no new entries");
         return false;
      }

      m_m.tradingAllowed=true;
      return true;
   }

   void OnTradeClosed(double closedProfit)
   {
      if(m_m==NULL) return;
      if(closedProfit>=0){ m_m.dailyProfit+=closedProfit; m_m.consecutiveLosses=0; }
      else               { m_m.dailyLoss+=MathAbs(closedProfit); m_m.consecutiveLosses++; }
   }

private:
   void SetHalted(string reason)
   {
      if(!m_m.tradingAllowed) return;
      m_m.tradingAllowed=false;
      Logger.Warning("RiskMonitor: Trading HALTED – "+reason);
   }
};

#endif
