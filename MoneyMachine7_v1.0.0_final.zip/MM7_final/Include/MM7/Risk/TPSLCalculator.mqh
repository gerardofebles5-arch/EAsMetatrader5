//+------------------------------------------------------------------+
//|  TPSLCalculator.mqh  -  Money Machine 7                          |
//+------------------------------------------------------------------+
#ifndef __MM7_TPSLCALC__
#define __MM7_TPSLCALC__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "..\Market\IndicatorCache.mqh"

class CTPSLCalculator
{
private:
   string            m_sym;
   bool              m_autoTP, m_autoSL, m_stealth;
   double            m_tpRatio, m_slRatio;
   int               m_digits;
   CIndicatorCache*  m_cache;

   double NP(double p){ return NormalizeDouble(p, m_digits); }

public:
   CTPSLCalculator(): m_autoTP(true), m_autoSL(true), m_stealth(true),
                      m_tpRatio(2), m_slRatio(1), m_digits(5), m_cache(NULL) {}

   void Init(string sym, bool autoTP, double tpRatio, bool autoSL, double slRatio,
             bool stealth, CIndicatorCache &cache)
   {
      m_sym=sym; m_autoTP=autoTP; m_tpRatio=tpRatio;
      m_autoSL=autoSL; m_slRatio=slRatio; m_stealth=stealth;
      m_digits=(int)SymbolInfoInteger(sym,SYMBOL_DIGITS);
      m_cache=&cache;
      Logger.Info("TPSLCalc: autoTP="+(autoTP?"Y":"N")+" tpR="+DoubleToString(tpRatio,1)
                  +" autoSL="+(autoSL?"Y":"N")+" slR="+DoubleToString(slRatio,1)
                  +" stealth="+(stealth?"Y":"N"));
   }

   TPSLResult Calculate(double entryPrice, ENUM_ORDER_TYPE type)
   {
      TPSLResult r; r.tp=0; r.sl=0; r.virtualTP=0; r.virtualSL=0;

      double atr=(m_cache!=NULL)?m_cache.GetATR(0):0;
      if(atr<=0){ Logger.Warning("TPSLCalc: ATR=0"); return r; }

      bool buy=(type==ORDER_TYPE_BUY);

      if(m_autoTP)
         r.virtualTP = NP(buy ? entryPrice+atr*m_tpRatio : entryPrice-atr*m_tpRatio);
      if(m_autoSL)
         r.virtualSL = NP(buy ? entryPrice-atr*m_slRatio : entryPrice+atr*m_slRatio);

      if(!m_stealth){ r.tp=r.virtualTP; r.sl=r.virtualSL; }

      Logger.Debug("TPSLCalc: vTP="+DoubleToString(r.virtualTP,m_digits)
                   +" vSL="+DoubleToString(r.virtualSL,m_digits)
                   +(m_stealth?" [stealth]":""));
      return r;
   }

   double GetATR() const { return (m_cache!=NULL)?m_cache.GetATR(0):0; }
};

#endif
