//+------------------------------------------------------------------+
//|  RecoveryMode.mqh  -  Money Machine 7                            |
//+------------------------------------------------------------------+
#ifndef __MM7_RECOVERY__
#define __MM7_RECOVERY__

#include "..\Utils\Logger.mqh"
#include "..\Core\DataStructures.mqh"
#include "PositionTracker.mqh"
#include "OrderExecutor.mqh"

class CRecoveryMode
{
private:
   bool              m_en;
   double            m_target;
   int               m_overlapX;
   CPositionTracker* m_tracker;
   COrderExecutor*   m_exec;

   void BubbleSort(PositionInfo &arr[], int n)
   {
      for(int i=0;i<n-1;i++)
         for(int j=0;j<n-1-i;j++)
            if(arr[j].profit > arr[j+1].profit)
            { PositionInfo tmp=arr[j]; arr[j]=arr[j+1]; arr[j+1]=tmp; }
   }

public:
   CRecoveryMode(): m_en(false), m_target(50), m_overlapX(3),
                    m_tracker(NULL), m_exec(NULL) {}

   void Init(bool en, double target, int overlapX, CPositionTracker &tr, COrderExecutor &ex)
   {
      m_en=en; m_target=target; m_overlapX=overlapX;
      m_tracker=&tr; m_exec=&ex;
      Logger.Info("Recovery: "+(en?"ENABLED":"DISABLED")
                  +" target="+DoubleToString(target,2)
                  +" overlapAfter="+IntegerToString(overlapX));
   }

   bool ManageRecovery()
   {
      if(!m_en || m_tracker.GetTotalCount()==0) return false;
      double totalPL=m_tracker.GetTotalProfit();
      if(totalPL < m_target) return false;

      PositionInfo all[];
      int cnt=m_tracker.GetAllPositions(all);
      BubbleSort(all, cnt);

      bool acted=false;
      for(int i=0;i<cnt;i++)
      {
         if(all[i].profit>=0) break;
         Logger.Info("Recovery: Closing loser #"+IntegerToString((int)all[i].ticket)
                     +" profit="+DoubleToString(all[i].profit,2));
         if(m_exec.ClosePosition(all[i].ticket))
         {
            acted=true;
            totalPL-=MathAbs(all[i].profit);
            if(totalPL < m_target) break;
         }
      }
      return acted;
   }

   bool IsNewPositionAllowed(ENUM_POSITION_TYPE newType)
   {
      if(!m_en) return true;
      if(m_tracker.GetTotalCount() >= m_overlapX) return true;
      int same=(newType==POSITION_TYPE_BUY)?m_tracker.GetBuyCount():m_tracker.GetSellCount();
      if(same>0)
      { Logger.Debug("Recovery: New entry blocked by overlap rule"); return false; }
      return true;
   }
};

#endif
